import nodemailer from 'nodemailer';
import { getEmailConfig } from '../config/email';

const getConfig = () => ({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export const sendReminderEmail = async (email: string, taskTitle: string, dueDate: Date) => {
  const config = getEmailConfig();
  if (!config) {
    console.log('Email not configured, skipping reminder');
    return false;
  }

  try {
    const transporter = nodemailer.createTransport(config);

    const formattedDate = dueDate.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    await transporter.sendMail({
      from: process.env.SMTP_USER,
      to: email,
      subject: `Reminder: "${taskTitle}" is due ${formattedDate}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Task Due Reminder</h2>
          <p>Hi there,</p>
          <p>This is a friendly reminder that your task <strong>"${taskTitle}"</strong> is due on <strong>${formattedDate}</strong>.</p>
          <p>Don't forget to complete it!</p>
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">You're receiving this email because you have notifications enabled for your To-Do App.</p>
        </div>
      `,
    });

    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
};

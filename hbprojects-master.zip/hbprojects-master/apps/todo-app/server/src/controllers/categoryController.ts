import { Response } from 'express';
import Category, { ICategory } from '../models/Category';
import { AuthRequest } from '../middleware/auth';

export const getCategories = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const categories = await Category.find({ userId: req.user.userId })
      .sort({ order: 1, name: 1 })
      .lean();

    // Also get task count for each category
    const Task = (await import('../models/Task')).default;
    const categoriesWithCounts = await Promise.all(
      categories.map(async (cat) => ({
        ...cat,
        taskCount: await Task.countDocuments({
          userId: req.user!.userId,
          categoryId: cat._id,
          status: { $ne: 'completed' },
        }),
      }))
    );

    res.status(200).json({ success: true, data: { categories: categoriesWithCounts } });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error fetching categories' } });
  }
};

export const createCategory = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { name, color } = req.body;

    if (!name) {
      res.status(400).json({ success: false, error: { message: 'Name is required' } });
      return;
    }

    // Check if category with same name exists
    const existing = await Category.findOne({ userId: req.user.userId, name });
    if (existing) {
      res.status(400).json({ success: false, error: { message: 'Category already exists' } });
      return;
    }

    // Get highest order for user
    const maxOrderCat = await Category.findOne({ userId: req.user.userId }).sort({ order: -1 });
    const order = (maxOrderCat?.order ?? -1) + 1;

    const category = await Category.create({
      userId: req.user.userId,
      name,
      color: color || '#3b82f6',
      order,
    });

    res.status(201).json({ success: true, data: { category } });
  } catch (error) {
    console.error('Create category error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error creating category' } });
  }
};

export const updateCategory = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { name, color } = req.body;

    const category = await Category.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      { name, color },
      { new: true, runValidators: true }
    );

    if (!category) {
      res.status(404).json({ success: false, error: { message: 'Category not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { category } });
  } catch (error) {
    console.error('Update category error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error updating category' } });
  }
};

export const deleteCategory = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const category = await Category.findOneAndDelete({
      _id: req.params.id,
      userId: req.user.userId,
    });

    if (!category) {
      res.status(404).json({ success: false, error: { message: 'Category not found' } });
      return;
    }

    // Remove category reference from tasks
    const Task = (await import('../models/Task')).default;
    await Task.updateMany(
      { categoryId: req.params.id },
      { $unset: { categoryId: '' } }
    );

    res.status(200).json({ success: true, data: { message: 'Category deleted' } });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error deleting category' } });
  }
};

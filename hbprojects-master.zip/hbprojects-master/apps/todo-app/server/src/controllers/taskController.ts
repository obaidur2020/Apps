import { Response } from 'express';
import Task, { ITask } from '../models/Task';
import { AuthRequest } from '../middleware/auth';
import mongoose from 'mongoose';
import type { FilterQuery, SortValues } from 'mongoose';

export const getTasks = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const {
      status,
      priority,
      categoryId,
      tags,
      search,
      dueBefore,
      dueAfter,
      sortBy = 'createdAt',
      order = 'desc',
      page = '1',
      limit = '20',
    } = req.query;

    // Build filter
    const filter: FilterQuery<ITask> = { userId: req.user.userId };

    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (categoryId) filter.categoryId = categoryId;
    if (tags) filter.tags = { $in: (tags as string).split(',') };
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }
    if (dueBefore) filter.dueDate = { ...filter.dueDate, $lte: new Date(dueBefore as string) };
    if (dueAfter) filter.dueDate = { ...filter.dueDate, $gte: new Date(dueAfter as string) };

    // Build sort
    const sort: Record<string, SortValues> = {};
    sort[sortBy as string] = order === 'asc' ? 1 : -1;

    // Pagination
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;

    const [tasks, total] = await Promise.all([
      Task.find(filter)
        .sort(sort)
        .skip(skip)
        .limit(limitNum)
        .populate('categoryId', 'name color')
        .lean(),
      Task.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: { tasks },
      meta: { page: pageNum, limit: limitNum, total },
    });
  } catch (error) {
    console.error('Get tasks error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error fetching tasks' } });
  }
};

export const getTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const task = await Task.findOne({
      _id: req.params.id,
      userId: req.user.userId,
    })
      .populate('categoryId', 'name color')
      .lean();

    if (!task) {
      res.status(404).json({ success: false, error: { message: 'Task not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { task } });
  } catch (error) {
    console.error('Get task error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error fetching task' } });
  }
};

export const createTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { title, description, status, priority, dueDate, tags, categoryId, subtasks } = req.body;

    if (!title) {
      res.status(400).json({ success: false, error: { message: 'Title is required' } });
      return;
    }

    // Get highest order for user
    const maxOrderTask = await Task.findOne({ userId: req.user.userId }).sort({ order: -1 });
    const order = (maxOrderTask?.order ?? -1) + 1;

    const task = await Task.create({
      userId: req.user.userId,
      title,
      description,
      status: status || 'pending',
      priority: priority || 'medium',
      dueDate,
      tags: tags || [],
      categoryId,
      subtasks: subtasks || [],
      order,
    });

    const populatedTask = await Task.findById(task._id).populate('categoryId', 'name color');

    res.status(201).json({ success: true, data: { task: populatedTask } });
  } catch (error) {
    console.error('Create task error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error creating task' } });
  }
};

export const updateTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { title, description, status, priority, dueDate, tags, categoryId, subtasks, order } =
      req.body;

    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      {
        title,
        description,
        status,
        priority,
        dueDate,
        tags,
        categoryId,
        subtasks,
        order,
        completedAt: status === 'completed' ? new Date() : null,
      },
      { new: true, runValidators: true }
    ).populate('categoryId', 'name color');

    if (!task) {
      res.status(404).json({ success: false, error: { message: 'Task not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { task } });
  } catch (error) {
    console.error('Update task error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error updating task' } });
  }
};

export const deleteTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const task = await Task.findOneAndDelete({
      _id: req.params.id,
      userId: req.user.userId,
    });

    if (!task) {
      res.status(404).json({ success: false, error: { message: 'Task not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { message: 'Task deleted' } });
  } catch (error) {
    console.error('Delete task error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error deleting task' } });
  }
};

export const updateTaskStatus = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { status } = req.body;

    if (!status || !['pending', 'in_progress', 'completed'].includes(status)) {
      res.status(400).json({ success: false, error: { message: 'Invalid status' } });
      return;
    }

    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      {
        status,
        completedAt: status === 'completed' ? new Date() : null,
      },
      { new: true }
    ).populate('categoryId', 'name color');

    if (!task) {
      res.status(404).json({ success: false, error: { message: 'Task not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { task } });
  } catch (error) {
    console.error('Update task status error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error updating status' } });
  }
};

export const reorderTasks = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { tasks } = req.body; // Array of { id, order }

    if (!Array.isArray(tasks)) {
      res.status(400).json({ success: false, error: { message: 'Invalid tasks array' } });
      return;
    }

    const bulkOps = tasks.map(({ id, order }: { id: string; order: number }) => ({
      updateOne: {
        filter: { _id: id, userId: req.user!.userId },
        update: { order },
      },
    }));

    await Task.bulkWrite(bulkOps);

    res.status(200).json({ success: true, data: { message: 'Tasks reordered' } });
  } catch (error) {
    console.error('Reorder tasks error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error reordering tasks' } });
  }
};

import cron from 'node-cron';
import User from '../models/User';
import Task from '../models/Task';
import { sendReminderEmail } from '../utils/sendEmail';

// Check for tasks due within reminder times every hour
export const startReminderJob = () => {
  // Run every hour at the top of the hour
  cron.schedule('0 * * * *', async () => {
    console.log('Running reminder job...');

    try {
      const now = new Date();
      const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000);

      // Find users who have notifications enabled
      const users = await User.find({
        'preferences.notifications.email': true,
      });

      for (const user of users) {
        // Get user's reminder times (in minutes before due date)
        const reminderTimes = user.preferences.notifications.reminderTimes || [15, 60, 1440];

        // Find pending tasks that haven't had reminders sent
        const tasks = await Task.find({
          userId: user._id,
          status: 'pending',
          dueDate: { $gte: now, $lte: oneHourLater },
          reminderSent: false,
        });

        for (const task of tasks) {
          if (!task.dueDate) continue;

          const dueDate = new Date(task.dueDate);
          const minutesUntilDue = (dueDate.getTime() - now.getTime()) / (1000 * 60);

          // Check if any reminder time matches (within 5 minutes)
          const shouldSend = reminderTimes.some(
            (time) => Math.abs(minutesUntilDue - time) < 5
          );

          if (shouldSend) {
            const sent = await sendReminderEmail(user.email, task.title, dueDate);
            if (sent) {
              task.reminderSent = true;
              await task.save();
              console.log(`Reminder sent for task "${task.title}" to ${user.email}`);
            }
          }
        }
      }

      console.log('Reminder job completed');
    } catch (error) {
      console.error('Error running reminder job:', error);
    }
  });

  console.log('Reminder job scheduled to run every hour');
};

import { Router } from 'express';
import { upload } from '../middleware/upload';
import { auth, AuthRequest } from '../middleware/auth';
import path from 'path';

const router = Router();

// All routes require authentication
router.use(auth);

// Upload file
router.post('/', upload.single('file'), (req: AuthRequest, res) => {
  if (!req.file) {
    return res.status(400).json({
      success: false,
      error: { message: 'No file uploaded' },
    });
  }

  res.status(200).json({
    success: true,
    data: {
      file: {
        filename: req.file.filename,
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        url: `/uploads/${req.file.filename}`,
      },
    },
  });
});

export default router;

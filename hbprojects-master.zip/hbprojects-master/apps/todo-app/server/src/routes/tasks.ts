import { Router } from 'express';
import {
  getTasks,
  getTask,
  createTask,
  updateTask,
  deleteTask,
  updateTaskStatus,
  reorderTasks,
} from '../controllers/taskController';
import { auth } from '../middleware/auth';

const router = Router();

// All routes require authentication
router.use(auth);

router.route('/').get(getTasks).post(createTask);
router.route('/reorder').post(reorderTasks);
router.route('/:id').get(getTask).put(updateTask).delete(deleteTask);
router.route('/:id/status').patch(updateTaskStatus);

export default router;

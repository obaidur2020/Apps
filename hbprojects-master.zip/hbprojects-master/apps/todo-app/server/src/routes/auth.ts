import { Router } from 'express';
import { register, login, logout, refreshToken, getProfile } from '../controllers/authController';
import { auth } from '../middleware/auth';

const router = Router();

router.post('/register', register);
router.post('/login', login);
router.post('/logout', auth, logout);
router.post('/refresh-token', refreshToken);
router.get('/profile', auth, getProfile);

export default router;

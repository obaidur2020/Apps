# To-Do List App

A full-stack task management application built with the MERN stack (MongoDB, Express, React, Node.js).

## 🚀 Quick Start with Docker

```bash
docker-compose up -d
```

### Access
- **Frontend**: http://localhost:5179
- **Backend API**: http://localhost:5000

## Features

- **Authentication**: User registration and login with JWT tokens
- **Task Management**: Create, read, update, and delete tasks
- **Task Properties**:
  - Title and description
  - Priority levels (low, medium, high, urgent)
  - Due dates
  - Status tracking (pending, in progress, completed)
  - Tags for categorization
- **Categories**: Organize tasks into color-coded categories
- **Smart Lists**: Quick filters for Today, Upcoming, Overdue, and Completed tasks
- **Advanced Filtering**: Filter by status, priority, and search
- **Dark/Light Theme**: Toggle between themes with auto-detection
- **Email Reminders**: Automated email notifications for due tasks

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite
- Tailwind CSS
- React Router DOM
- React Hot Toast
- Axios
- date-fns
- Lucide React (icons)

### Backend
- Node.js with Express
- TypeScript
- MongoDB with Mongoose
- JWT authentication
- Bcrypt for password hashing
- Nodemailer for email
- Node-cron for scheduled jobs

## Project Structure

```
todo-app/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── context/       # React context (Auth, Theme)
│   │   ├── hooks/         # Custom hooks
│   │   ├── pages/         # Page components
│   │   ├── services/      # API services
│   │   └── types/         # TypeScript types
│   └── ...
└── server/                # Express backend
    ├── src/
    │   ├── config/        # Configuration files
    │   ├── controllers/   # Route controllers
    │   ├── jobs/          # Scheduled jobs
    │   ├── middleware/    # Express middleware
    │   ├── models/        # Mongoose models
    │   ├── routes/        # API routes
    │   ├── utils/         # Utility functions
    │   └── server.ts      # Server entry point
    └── ...
```

## Getting Started

### Prerequisites

- Node.js 18+
- MongoDB (local or MongoDB Atlas)
- npm or yarn

### Installation

1. Clone the repository and navigate to the project

2. Install server dependencies:
```bash
cd server
npm install
```

3. Install client dependencies:
```bash
cd ../client
npm install
```

### Configuration

1. Create a `.env` file in the `server` directory:
```bash
cd server
cp .env.example .env
```

2. Update the `.env` file with your configuration:
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/todo-app
JWT_SECRET=your_jwt_secret_here
JWT_REFRESH_SECRET=your_refresh_secret_here
CLIENT_URL=http://localhost:5173

# Optional: Email notifications
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
```

3. For Gmail, you'll need to create an app password: https://support.google.com/accounts/answer/185833

### Running the Application

1. Start MongoDB (if running locally)

2. Start the backend server:
```bash
cd server
npm run dev
```

3. Start the frontend (in a new terminal):
```bash
cd client
npm run dev
```

4. Open your browser to `http://localhost:5173`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `POST /api/auth/refresh-token` - Refresh access token
- `GET /api/auth/profile` - Get user profile

### Tasks
- `GET /api/tasks` - Get user's tasks (with filters)
- `POST /api/tasks` - Create a new task
- `GET /api/tasks/:id` - Get a single task
- `PUT /api/tasks/:id` - Update a task
- `DELETE /api/tasks/:id` - Delete a task
- `PATCH /api/tasks/:id/status` - Update task status

### Categories
- `GET /api/categories` - Get user's categories
- `POST /api/categories` - Create a category
- `PUT /api/categories/:id` - Update a category
- `DELETE /api/categories/:id` - Delete a category

### Upload
- `POST /api/upload` - Upload a file

## License

MIT

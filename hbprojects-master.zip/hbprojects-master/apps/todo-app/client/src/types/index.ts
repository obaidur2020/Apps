export interface User {
  _id: string;
  email: string;
  name: string;
  avatar?: string;
  preferences: {
    theme: 'light' | 'dark' | 'auto';
    notifications: {
      email: boolean;
      browser: boolean;
      reminderTimes: number[];
    };
    timezone: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  _id: string;
  userId: string;
  title: string;
  description?: string;
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  dueDate?: string;
  reminderSent: boolean;
  tags: string[];
  categoryId?: string;
  subtasks: Subtask[];
  attachments: Attachment[];
  order: number;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Subtask {
  _id: string;
  title: string;
  completed: boolean;
}

export interface Attachment {
  filename: string;
  url: string;
  mimeType: string;
  size: number;
}

export interface Category {
  _id: string;
  userId: string;
  name: string;
  color: string;
  order: number;
  createdAt: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
}

export interface ApiError {
  message: string;
  code?: string;
  details?: Record<string, unknown>;
  response?: {
    data?: {
      error?: ApiError;
    };
    status?: number;
  };
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    message: string;
    code?: string;
    details?: Record<string, unknown>;
  };
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
  };
}

import api from './api';
import type { Category, ApiResponse } from '../types';

export const categoryService = {
  async getCategories(): Promise<Category[]> {
    const response = await api.get<ApiResponse<{ categories: Category[] }>>('/categories');
    return response.data.data!.categories;
  },

  async createCategory(name: string, color: string): Promise<Category> {
    const response = await api.post<ApiResponse<{ category: Category }>>('/categories', {
      name,
      color,
    });
    return response.data.data!.category;
  },

  async updateCategory(id: string, name: string, color: string): Promise<Category> {
    const response = await api.put<ApiResponse<{ category: Category }>>(`/categories/${id}`, {
      name,
      color,
    });
    return response.data.data!.category;
  },

  async deleteCategory(id: string): Promise<void> {
    await api.delete(`/categories/${id}`);
  },
};

import api from './api';
import type { Task, ApiResponse } from '../types';

export type TaskFilters = {
  status?: string;
  priority?: string;
  categoryId?: string;
  tags?: string;
  search?: string;
  dueBefore?: string;
  dueAfter?: string;
  sortBy?: string;
  order?: 'asc' | 'desc';
  page?: number;
  limit?: number;
};

export type CreateTaskData = {
  title: string;
  description?: string;
  status?: 'pending' | 'in_progress' | 'completed';
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  dueDate?: string;
  tags?: string[];
  categoryId?: string;
  subtasks?: Array<{ title: string; completed: boolean }>;
};

export const taskService = {
  async getTasks(filters?: TaskFilters): Promise<{ tasks: Task[]; total: number }> {
    const params = new URLSearchParams();
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined) {
          params.append(key, String(value));
        }
      });
    }

    const response = await api.get<ApiResponse<{ tasks: Task[] } & { meta?: { total: number } }>>(
      `/tasks?${params.toString()}`
    );
    return {
      tasks: response.data.data!.tasks,
      total: response.data.meta?.total || 0,
    };
  },

  async getTask(id: string): Promise<Task> {
    const response = await api.get<ApiResponse<{ task: Task }>>(`/tasks/${id}`);
    return response.data.data!.task;
  },

  async createTask(data: CreateTaskData): Promise<Task> {
    const response = await api.post<ApiResponse<{ task: Task }>>('/tasks', data);
    return response.data.data!.task;
  },

  async updateTask(id: string, data: Partial<CreateTaskData>): Promise<Task> {
    const response = await api.put<ApiResponse<{ task: Task }>>(`/tasks/${id}`, data);
    return response.data.data!.task;
  },

  async deleteTask(id: string): Promise<void> {
    await api.delete(`/tasks/${id}`);
  },

  async updateTaskStatus(id: string, status: 'pending' | 'in_progress' | 'completed'): Promise<Task> {
    const response = await api.patch<ApiResponse<{ task: Task }>>(`/tasks/${id}/status`, { status });
    return response.data.data!.task;
  },

  async reorderTasks(tasks: Array<{ id: string; order: number }>): Promise<void> {
    await api.post('/tasks/reorder', { tasks });
  },
};

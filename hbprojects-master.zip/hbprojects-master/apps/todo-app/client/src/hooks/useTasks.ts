import { useState, useEffect, useCallback } from 'react';
import { taskService, type TaskFilters, type CreateTaskData } from '../services/taskService';
import type { Task, ApiError } from '../types';
import toast from 'react-hot-toast';

export const useTasks = (filters?: TaskFilters) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const result = await taskService.getTasks(filters);
      setTasks(result.tasks);
      setTotal(result.total);
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to fetch tasks';
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const createTask = async (data: CreateTaskData): Promise<Task | null> => {
    try {
      const newTask = await taskService.createTask(data);
      setTasks((prev) => [newTask, ...prev]);
      setTotal((prev) => prev + 1);
      toast.success('Task created');
      return newTask;
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to create task';
      toast.error(message);
      return null;
    }
  };

  const updateTask = async (id: string, data: Partial<CreateTaskData>): Promise<Task | null> => {
    try {
      const updatedTask = await taskService.updateTask(id, data);
      setTasks((prev) => prev.map((t) => (t._id === id ? updatedTask : t)));
      toast.success('Task updated');
      return updatedTask;
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to update task';
      toast.error(message);
      return null;
    }
  };

  const deleteTask = async (id: string): Promise<boolean> => {
    try {
      await taskService.deleteTask(id);
      setTasks((prev) => prev.filter((t) => t._id !== id));
      setTotal((prev) => prev - 1);
      toast.success('Task deleted');
      return true;
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to delete task';
      toast.error(message);
      return false;
    }
  };

  const updateStatus = async (id: string, status: 'pending' | 'in_progress' | 'completed') => {
    try {
      const updatedTask = await taskService.updateTaskStatus(id, status);
      setTasks((prev) => prev.map((t) => (t._id === id ? updatedTask : t)));
      toast.success(`Task marked as ${status}`);
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to update status';
      toast.error(message);
    }
  };

  return {
    tasks,
    loading,
    total,
    refetch: fetchTasks,
    createTask,
    updateTask,
    deleteTask,
    updateStatus,
  };
};

import { useState, useEffect, useCallback } from 'react';
import { categoryService } from '../services/categoryService';
import type { Category, ApiError } from '../types';
import toast from 'react-hot-toast';

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    try {
      const data = await categoryService.getCategories();
      setCategories(data);
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to fetch categories';
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const createCategory = async (name: string, color: string): Promise<Category | null> => {
    try {
      const newCategory = await categoryService.createCategory(name, color);
      setCategories((prev) => [...prev, newCategory]);
      toast.success('Category created');
      return newCategory;
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to create category';
      toast.error(message);
      return null;
    }
  };

  const updateCategory = async (id: string, name: string, color: string): Promise<Category | null> => {
    try {
      const updated = await categoryService.updateCategory(id, name, color);
      setCategories((prev) => prev.map((c) => (c._id === id ? updated : c)));
      toast.success('Category updated');
      return updated;
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to update category';
      toast.error(message);
      return null;
    }
  };

  const deleteCategory = async (id: string): Promise<boolean> => {
    if (!window.confirm('Delete this category? Tasks will be unassigned.')) {
      return false;
    }
    try {
      await categoryService.deleteCategory(id);
      setCategories((prev) => prev.filter((c) => c._id !== id));
      toast.success('Category deleted');
      return true;
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to delete category';
      toast.error(message);
      return false;
    }
  };

  return {
    categories,
    loading,
    refetch: fetchCategories,
    createCategory,
    updateCategory,
    deleteCategory,
  };
};

import { CheckCircle, Clock, AlertCircle, ListTodo } from 'lucide-react';

type SmartListType = 'all' | 'today' | 'upcoming' | 'overdue' | 'completed';

interface SmartListNavProps {
  activeList: SmartListType;
  onChange: (list: SmartListType) => void;
}

const smartLists = [
  { id: 'all' as SmartListType, label: 'All Tasks', icon: ListTodo },
  { id: 'today' as SmartListType, label: 'Today', icon: Clock },
  { id: 'upcoming' as SmartListType, label: 'Upcoming', icon: AlertCircle },
  { id: 'overdue' as SmartListType, label: 'Overdue', icon: AlertCircle },
  { id: 'completed' as SmartListType, label: 'Completed', icon: CheckCircle },
];

export const SmartListNav = ({ activeList, onChange }: SmartListNavProps) => {
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      {smartLists.map((list) => {
        const Icon = list.icon;
        return (
          <button
            key={list.id}
            onClick={() => onChange(list.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeList === list.id
                ? 'bg-primary-600 text-white'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
          >
            <Icon className="w-4 h-4" />
            {list.label}
          </button>
        );
      })}
    </div>
  );
};

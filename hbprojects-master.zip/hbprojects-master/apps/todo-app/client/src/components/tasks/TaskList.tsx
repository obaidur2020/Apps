import type { Task, Category } from '../../types';
import { TaskCard } from './TaskCard';
import { TaskModal } from './TaskModal';
import type { TaskFormData } from './TaskForm';
import type { CreateTaskData } from '../../services/taskService';
import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../common/Button';

interface TaskListProps {
  tasks: Task[];
  categories?: Category[];
  selectedCategoryId?: string;
  loading: boolean;
  onCreateTask: (data: CreateTaskData) => Promise<boolean>;
  onUpdateTask: (id: string, data: Partial<CreateTaskData>) => Promise<boolean>;
  onDeleteTask: (id: string) => Promise<boolean>;
  onUpdateStatus: (
    id: string,
    status: 'pending' | 'in_progress' | 'completed'
  ) => Promise<void>;
}

function taskFormDataToCreateTaskData(formData: TaskFormData): CreateTaskData {
  return {
    title: formData.title,
    description: formData.description || undefined,
    status: formData.status,
    priority: formData.priority,
    dueDate: formData.dueDate || undefined,
    tags: formData.tags
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0),
    categoryId: formData.categoryId,
  };
}

function taskFormDataToUpdateData(formData: TaskFormData): Partial<CreateTaskData> {
  return {
    title: formData.title,
    description: formData.description || undefined,
    status: formData.status,
    priority: formData.priority,
    dueDate: formData.dueDate || undefined,
    tags: formData.tags
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0),
    categoryId: formData.categoryId,
  };
}

export const TaskList = ({
  tasks,
  categories = [],
  selectedCategoryId,
  loading,
  onCreateTask,
  onUpdateTask,
  onDeleteTask,
  onUpdateStatus,
}: TaskListProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCreate = async (data: TaskFormData) => {
    setIsSubmitting(true);
    const createData = taskFormDataToCreateTaskData(data);
    const success = await onCreateTask(createData);
    setIsSubmitting(false);
    if (success) {
      setIsModalOpen(false);
    }
    return success;
  };

  const handleUpdate = async (data: TaskFormData) => {
    if (!editingTask) return false;
    setIsSubmitting(true);
    const updateData = taskFormDataToUpdateData(data);
    const success = await onUpdateTask(editingTask._id, updateData);
    setIsSubmitting(false);
    if (success) {
      setIsModalOpen(false);
      setEditingTask(undefined);
    }
    return success;
  };

  const openCreateModal = () => {
    setEditingTask(undefined);
    setIsModalOpen(true);
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingTask(undefined);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          {tasks.length === 0 ? 'No tasks yet' : `Your Tasks (${tasks.length})`}
        </h2>
        <Button onClick={openCreateModal} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Task
        </Button>
      </div>

      {tasks.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg">
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            No tasks found. Create your first task to get started!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {tasks.map((task) => (
            <TaskCard
              key={task._id}
              task={task}
              onStatusChange={(id, status) => onUpdateStatus(id, status)}
              onEdit={openEditModal}
              onDelete={(id) => onDeleteTask(id)}
            />
          ))}
        </div>
      )}

      <TaskModal
        task={editingTask}
        categories={categories}
        selectedCategoryId={selectedCategoryId}
        isOpen={isModalOpen}
        onClose={closeModal}
        onSubmit={editingTask ? handleUpdate : handleCreate}
        loading={isSubmitting}
      />
    </div>
  );
};

import { X } from 'lucide-react';
import type { Task, Category } from '../../types';
import { TaskForm, type TaskFormData } from './TaskForm';

interface TaskModalProps {
  task?: Task;
  categories?: Category[];
  selectedCategoryId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: TaskFormData) => void;
  loading?: boolean;
}

export const TaskModal = ({
  task,
  categories = [],
  selectedCategoryId,
  isOpen,
  onClose,
  onSubmit,
  loading,
}: TaskModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {task ? 'Edit Task' : 'New Task'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4">
          <TaskForm
            task={task}
            categories={categories}
            selectedCategoryId={selectedCategoryId}
            onSubmit={onSubmit}
            onCancel={onClose}
            loading={loading}
          />
        </div>
      </div>
    </div>
  );
};

import type { Category } from '../../types';
import { FolderOpen, Trash2, Edit2 } from 'lucide-react';

interface CategoryListProps {
  categories: Category[];
  selectedId?: string;
  onSelect: (id: string | undefined) => void;
  onEdit: (category: Category) => void;
  onDelete: (id: string) => void;
}

export const CategoryList = ({
  categories,
  selectedId,
  onSelect,
  onEdit,
  onDelete,
}: CategoryListProps) => {
  return (
    <div className="space-y-1">
      <button
        onClick={() => onSelect(undefined)}
        className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left transition-colors ${
          !selectedId
            ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-200'
            : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'
        }`}
      >
        <FolderOpen className="w-4 h-4" />
        <span className="font-medium">All Tasks</span>
      </button>

      {categories.map((category) => (
        <div
          key={category._id}
          className={`group flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
            selectedId === category._id
              ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-200'
              : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'
          }`}
        >
          <button
            onClick={() => onSelect(category._id)}
            className="flex items-center gap-2 flex-1 min-w-0"
          >
            <div
              className="w-3 h-3 rounded-full flex-shrink-0"
              style={{ backgroundColor: category.color }}
            />
            <span className="truncate font-medium">{category.name}</span>
            {('taskCount' in category ? (category as any).taskCount : 0) > 0 && (
              <span className="text-xs bg-gray-200 dark:bg-gray-700 px-1.5 py-0.5 rounded">
                {(category as any).taskCount}
              </span>
            )}
          </button>

          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => onEdit(category)}
              className="p-1 text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-400"
            >
              <Edit2 className="w-3 h-3" />
            </button>
            <button
              onClick={() => onDelete(category._id)}
              className="p-1 text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

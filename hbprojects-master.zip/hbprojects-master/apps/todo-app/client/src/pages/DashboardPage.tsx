import { useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTasks } from '../hooks/useTasks';
import { useCategories } from '../hooks/useCategories';
import { TaskList } from '../components/tasks/TaskList';
import { CategoryList } from '../components/categories/CategoryList';
import { CategoryModal } from '../components/categories/CategoryModal';
import { SmartListNav } from '../components/tasks/SmartListNav';
import { TaskFilters } from '../components/tasks/TaskFilters';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { type CreateTaskData, type TaskFilters as TaskFiltersType } from '../services/taskService';
import { Plus } from 'lucide-react';
import type { Category } from '../types';
import { isToday, isPast, isFuture } from 'date-fns';

type SmartListType = 'all' | 'today' | 'upcoming' | 'overdue' | 'completed';

export const DashboardPage = () => {
  const { user, logout } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  const [smartList, setSmartList] = useState<SmartListType>('all');
  const [additionalFilters, setAdditionalFilters] = useState<Partial<TaskFiltersType>>({});
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | undefined>();
  const [isSubmittingCategory, setIsSubmittingCategory] = useState(false);

  const queryFilters = useMemo(() => {
    const filters: TaskFiltersType = {};
    if (smartList === 'today') {
      filters.status = 'pending';
    } else if (smartList === 'completed') {
      filters.status = 'completed';
    } else if (smartList === 'overdue') {
      filters.status = 'pending';
    } else if (smartList === 'upcoming') {
      filters.status = 'pending';
    }
    if (selectedCategory) {
      filters.categoryId = selectedCategory;
    }
    if (additionalFilters.status) filters.status = additionalFilters.status;
    if (additionalFilters.priority) filters.priority = additionalFilters.priority;
    if (additionalFilters.search) filters.search = additionalFilters.search;
    return filters;
  }, [smartList, selectedCategory, additionalFilters]);

  const { tasks, loading, createTask, updateTask, deleteTask, updateStatus, refetch } =
    useTasks(queryFilters);

  const filteredTasks = useMemo(() => {
    if (smartList === 'today') {
      return tasks.filter((t) => t.dueDate && isToday(new Date(t.dueDate)));
    } else if (smartList === 'upcoming') {
      return tasks.filter((t) => t.dueDate && isFuture(new Date(t.dueDate)));
    } else if (smartList === 'overdue') {
      return tasks.filter((t) => t.dueDate && isPast(new Date(t.dueDate)));
    }
    return tasks;
  }, [tasks, smartList]);

  const { categories, createCategory, updateCategory, deleteCategory } = useCategories();

  const handleCreateTask = async (data: CreateTaskData) => {
    const result = await createTask(data);
    if (result) refetch();
    return !!result;
  };

  const handleUpdateTask = async (id: string, data: Partial<CreateTaskData>) => {
    const result = await updateTask(id, data);
    if (result) refetch();
    return !!result;
  };

  const handleDeleteTask = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      const result = await deleteTask(id);
      if (result) refetch();
      return result;
    }
    return false;
  };

  const handleCreateCategory = async (name: string, color: string) => {
    setIsSubmittingCategory(true);
    const result = await createCategory(name, color);
    setIsSubmittingCategory(false);
    if (result) setCategoryModalOpen(false);
  };

  const handleUpdateCategory = async (name: string, color: string) => {
    if (!editingCategory) return;
    setIsSubmittingCategory(true);
    const result = await updateCategory(editingCategory._id, name, color);
    setIsSubmittingCategory(false);
    if (result) {
      setCategoryModalOpen(false);
      setEditingCategory(undefined);
    }
  };

  const openEditCategory = (category: Category) => {
    setEditingCategory(category);
    setCategoryModalOpen(true);
  };

  const openNewCategory = () => {
    setEditingCategory(undefined);
    setCategoryModalOpen(true);
  };

  const closeCategoryModal = () => {
    setCategoryModalOpen(false);
    setEditingCategory(undefined);
  };

  const handleSmartListChange = (list: SmartListType) => {
    setSmartList(list);
    setSelectedCategory(undefined);
    setAdditionalFilters({});
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">To-Do App</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-700 dark:text-gray-300">Welcome, {user?.name}</span>
            <ThemeToggle />
            <button
              onClick={logout}
              className="px-4 py-2 text-sm bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          <aside className="w-64 flex-shrink-0">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 sticky top-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Categories</h2>
                <button
                  onClick={openNewCategory}
                  className="p-1 text-primary-600 hover:bg-primary-50 rounded dark:hover:bg-gray-700"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <CategoryList
                categories={categories}
                selectedId={selectedCategory}
                onSelect={(id) => {
                  setSelectedCategory(id);
                  setSmartList('all');
                }}
                onEdit={openEditCategory}
                onDelete={(id) => deleteCategory(id)}
              />
            </div>
          </aside>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <SmartListNav activeList={smartList} onChange={handleSmartListChange} />
              <TaskFilters filters={additionalFilters} onChange={setAdditionalFilters} />
            </div>
            <TaskList
              tasks={filteredTasks}
              categories={categories}
              selectedCategoryId={selectedCategory}
              loading={loading}
              onCreateTask={handleCreateTask}
              onUpdateTask={handleUpdateTask}
              onDeleteTask={handleDeleteTask}
              onUpdateStatus={updateStatus}
            />
          </div>
        </div>
      </main>

      <CategoryModal
        category={editingCategory}
        isOpen={categoryModalOpen}
        onClose={closeCategoryModal}
        onSubmit={editingCategory ? handleUpdateCategory : handleCreateCategory}
        loading={isSubmittingCategory}
      />
    </div>
  );
};

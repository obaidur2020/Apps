# Real Estate Listings

A full-stack real estate application with property management and advanced filtering.

## 🚀 Quick Start

```bash
docker-compose up -d
```

## 🌐 Access

- **Frontend**: http://localhost:5178
- **Backend API**: http://localhost:5006
- **Health Check**: http://localhost:5006/health

## ✨ Features

- Add, edit, and delete properties
- Advanced filtering (type, status, price range, bedrooms)
- Property details (bedrooms, bathrooms, square footage)
- Image support
- Location-based search
- For sale / For rent listings
- Modern gradient UI with glassmorphism
- Responsive design

## 🔧 Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript, MongoDB
- **Database**: MongoDB

## 📁 Structure

```
real-estate/
├── client/          # React frontend
│   └── src/
│       ├── components/
│       └── services/
└── server/          # Express backend
    └── src/
        ├── models/
        ├── routes/
        └── controllers/
```

## 🐳 Docker Services

- `real-estate-server` - Backend API (port 5006)
- `real-estate-client` - Frontend UI (port 5178)

## 📝 API Endpoints

- `GET /api/properties` - Get all properties (with filters)
- `POST /api/properties` - Create property
- `GET /api/properties/:id` - Get property by ID
- `PUT /api/properties/:id` - Update property
- `DELETE /api/properties/:id` - Delete property

## 🔍 Filter Parameters

- `type` - Property type (house, apartment, condo, etc.)
- `status` - Sale or rent
- `minPrice` - Minimum price
- `maxPrice` - Maximum price
- `bedrooms` - Minimum bedrooms

import mongoose from 'mongoose';

export interface IProperty {
  title: string;
  description?: string;
  type?: 'house' | 'apartment' | 'condo' | 'townhouse' | 'land';
  status?: 'sale' | 'rent';
  price: number;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
  };
  location?: {
    type: 'Point';
    coordinates: [number, number];
  };
  details?: {
    bedrooms?: number;
    bathrooms?: number;
    sqft?: number;
    yearBuilt?: number;
    lotSize?: number;
    parking?: number;
    amenities?: string[];
  };
  images?: Array<{ url?: string; caption?: string }>;
  agentId?: string;
  featured?: boolean;
  views?: number;
  createdAt?: Date;
  updatedAt?: Date;
}

const PropertySchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  type: { type: String, enum: ['house', 'apartment', 'condo', 'townhouse', 'land'] },
  status: { type: String, enum: ['sale', 'rent'] },
  price: { type: Number, required: true },
  address: { street: String, city: String, state: String, zip: String, country: String },
  location: { type: { type: String, enum: ['Point'] }, coordinates: [Number] },
  details: {
    bedrooms: Number,
    bathrooms: Number,
    sqft: Number,
    yearBuilt: Number,
    lotSize: Number,
    parking: Number,
    amenities: [String],
  },
  images: [{ url: String, caption: String }],
  agentId: String,
  featured: { type: Boolean, default: false },
  views: { type: Number, default: 0 },
}, { timestamps: true });

PropertySchema.index({ type: 1, status: 1, price: 1 });
PropertySchema.index({ 'location.coordinates': '2dsphere' });

export default mongoose.model('Property', PropertySchema);

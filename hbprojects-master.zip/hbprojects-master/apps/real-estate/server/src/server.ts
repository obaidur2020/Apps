import express, { Request, Response } from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Property, { IProperty } from './models/Property';
import type { FilterQuery } from 'mongoose';

dotenv.config();
const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/real-estate';
const port = process.env.PORT || 5006;
const clientOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5180';

mongoose.connect(mongoUri);

const app = express();
app.use(cors({ origin: clientOrigin }));
app.use(express.json());

app.get('/health', (_req: Request, res: Response) => res.json({ status: 'OK' }));

app.get('/api/properties', async (req: Request, res: Response) => {
  const { type, status, minPrice, maxPrice, bedrooms } = req.query;
  const filter: FilterQuery<IProperty> = {};

  if (type) filter.type = type;
  if (status) filter.status = status;
  if (minPrice) filter.price = { $gte: Number(minPrice) };
  if (maxPrice) filter.price = { ...filter.price, $lte: Number(maxPrice) };
  if (bedrooms) filter['details.bedrooms'] = { $gte: Number(bedrooms) };

  const properties = await Property.find(filter).sort({ createdAt: -1 });
  res.json({ success: true, data: { properties } });
});

app.post('/api/properties', async (req: Request, res: Response) => {
  const property = await Property.create(req.body);
  res.status(201).json({ success: true, data: { property } });
});

app.get('/api/properties/:id', async (req: Request, res: Response) => {
  const property = await Property.findById(req.params.id);
  if (!property) return res.status(404).json({ success: false, error: 'Not found' });
  property.views++;
  await property.save();
  res.json({ success: true, data: { property } });
});

app.put('/api/properties/:id', async (req: Request, res: Response) => {
  const property = await Property.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!property) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: { property } });
});

app.delete('/api/properties/:id', async (req: Request, res: Response) => {
  const property = await Property.findByIdAndDelete(req.params.id);
  if (!property) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: { property } });
});

app.listen(port, () => console.log(`Real Estate Server on ${port}`));

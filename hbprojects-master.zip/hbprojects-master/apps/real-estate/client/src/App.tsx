import { useState, useEffect } from 'react';
import { Home, Search, MapPin, Bed, Bath, Maximize, Plus, Edit2, Trash2, X, Image as ImageIcon } from 'lucide-react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';

const API_URL = 'http://localhost:5006/api';

interface PropertyDetails {
  bedrooms?: number;
  bathrooms?: number;
  sqft?: number;
}

interface Property {
  _id: string;
  title: string;
  description: string;
  price: number;
  type: string;
  status: 'sale' | 'rent';
  location: string;
  details?: PropertyDetails;
  images: string[];
  createdAt: string;
}

interface PropertyFilters {
  type: string;
  status: string;
  minPrice: string;
  maxPrice: string;
  bedrooms: string;
}

interface PropertyFormData {
  title: string;
  description: string;
  price: string;
  type: string;
  status: 'sale' | 'rent';
  location: string;
  bedrooms: string;
  bathrooms: string;
  sqft: string;
  images: string;
}

function App() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [filters, setFilters] = useState<PropertyFilters>({ type: '', status: '', minPrice: '', maxPrice: '', bedrooms: '' });
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [formData, setFormData] = useState<PropertyFormData>({
    title: '',
    description: '',
    price: '',
    type: 'house',
    status: 'sale',
    location: '',
    bedrooms: '',
    bathrooms: '',
    sqft: '',
    images: ''
  });

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    try {
      const res = await axios.get(`${API_URL}/properties`, { params: filters });
      setProperties(res.data.data.properties);
    } catch (error) {
      console.error('Failed to load properties:', error);
    }
  };

  const openAddModal = () => {
    setEditingProperty(null);
    setFormData({
      title: '',
      description: '',
      price: '',
      type: 'house',
      status: 'sale',
      location: '',
      bedrooms: '',
      bathrooms: '',
      sqft: '',
      images: ''
    });
    setModalOpen(true);
  };

  const openEditModal = (property: Property) => {
    setEditingProperty(property);
    setFormData({
      title: property.title,
      description: property.description,
      price: property.price.toString(),
      type: property.type,
      status: property.status,
      location: property.location,
      bedrooms: property.details?.bedrooms?.toString() || '',
      bathrooms: property.details?.bathrooms?.toString() || '',
      sqft: property.details?.sqft?.toString() || '',
      images: property.images?.join(', ') || ''
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        title: formData.title,
        description: formData.description,
        price: Number(formData.price),
        type: formData.type,
        status: formData.status,
        location: formData.location,
        details: {
          bedrooms: Number(formData.bedrooms) || 0,
          bathrooms: Number(formData.bathrooms) || 0,
          sqft: Number(formData.sqft) || 0
        },
        images: formData.images.split(',').map(url => url.trim()).filter(Boolean)
      };

      if (editingProperty) {
        await axios.put(`${API_URL}/properties/${editingProperty._id}`, payload);
        toast.success('Property updated!');
      } else {
        await axios.post(`${API_URL}/properties`, payload);
        toast.success('Property added!');
      }

      setModalOpen(false);
      loadProperties();
    } catch (error) {
      toast.error('Failed to save property');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this property?')) return;
    try {
      await axios.delete(`${API_URL}/properties/${id}`);
      toast.success('Property deleted!');
      loadProperties();
    } catch (error) {
      toast.error('Failed to delete property');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-teal-50 dark:from-slate-900 dark:to-slate-800">
      <Toaster position="top-right" />

      {/* Header */}
      <header className="bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl">
              <Home className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">RealEstate Hub</h1>
              <p className="text-teal-100 text-sm">Find your perfect property</p>
            </div>
          </div>
          <button
            onClick={openAddModal}
            className="flex items-center gap-2 px-5 py-2.5 bg-white text-teal-600 rounded-xl font-semibold hover:bg-teal-50 transition-all shadow-lg hover:shadow-xl"
          >
            <Plus className="w-5 h-5" /> Add Property
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Filters */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-5 h-5 text-teal-600" />
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Search Properties</h2>
          </div>
          <div className="grid md:grid-cols-6 gap-4">
            <input
              value={filters.type}
              onChange={(e) => setFilters({...filters, type: e.target.value})}
              placeholder="Property Type"
              className="px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
            <select
              value={filters.status}
              onChange={(e) => setFilters({...filters, status: e.target.value})}
              className="px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
            >
              <option value="">Any Status</option>
              <option value="sale">For Sale</option>
              <option value="rent">For Rent</option>
            </select>
            <input
              type="number"
              value={filters.minPrice}
              onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
              placeholder="Min Price"
              className="px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
            />
            <input
              type="number"
              value={filters.maxPrice}
              onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
              placeholder="Max Price"
              className="px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
            />
            <select
              value={filters.bedrooms}
              onChange={(e) => setFilters({...filters, bedrooms: e.target.value})}
              className="px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
            >
              <option value="">Any Beds</option>
              <option value="1">1+</option>
              <option value="2">2+</option>
              <option value="3">3+</option>
              <option value="4">4+</option>
            </select>
            <button
              onClick={loadProperties}
              className="px-6 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-xl font-semibold hover:from-teal-700 hover:to-emerald-700 transition-all shadow-md hover:shadow-lg"
            >
              Search
            </button>
          </div>
        </div>

        {/* Properties Grid */}
        {properties.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-24 h-24 mx-auto mb-6 bg-teal-100 dark:bg-teal-900/30 rounded-full flex items-center justify-center">
              <Home className="w-12 h-12 text-teal-500" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">No properties found</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6">Add your first property to get started</p>
            <button
              onClick={openAddModal}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-xl font-semibold hover:from-teal-700 hover:to-emerald-700 transition-all"
            >
              <Plus className="w-5 h-5" /> Add Property
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((prop) => (
              <div key={prop._id} className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow group">
                {/* Image */}
                <div className="relative h-48 bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center text-white text-5xl font-bold">
                  {prop.title[0]}
                  <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEditModal(prop)}
                      className="p-2 bg-white/90 rounded-lg text-teal-600 hover:bg-white transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(prop._id)}
                      className="p-2 bg-white/90 rounded-lg text-red-500 hover:bg-white transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="absolute bottom-3 left-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${prop.status === 'sale' ? 'bg-emerald-500' : 'bg-blue-500'}`}>
                      {prop.status === 'sale' ? 'For Sale' : 'For Rent'}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white">{prop.title}</h3>
                    <span className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400">
                      <MapPin className="w-3 h-3" />
                      {prop.location}
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-teal-600 mb-3">${prop.price.toLocaleString()}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 line-clamp-2">{prop.description}</p>

                  {/* Details */}
                  <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 pt-4 border-t border-gray-100 dark:border-gray-700">
                    <span className="flex items-center gap-1.5">
                      <Bed className="w-4 h-4" />
                      {prop.details?.bedrooms || 0} beds
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Bath className="w-4 h-4" />
                      {prop.details?.bathrooms || 0} baths
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Maximize className="w-4 h-4" />
                      {prop.details?.sqft || 0} sqft
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModalOpen(false)}></div>
          <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-800 dark:text-white">
                {editingProperty ? 'Edit Property' : 'Add New Property'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Property Title *</label>
                  <input
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    placeholder="e.g. Modern Villa"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Property Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="house">House</option>
                    <option value="apartment">Apartment</option>
                    <option value="condo">Condo</option>
                    <option value="townhouse">Townhouse</option>
                    <option value="land">Land</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe the property..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500 resize-none"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Price ($) *</label>
                  <input
                    required
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    placeholder="500000"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({...formData, status: e.target.value as 'sale' | 'rent'})}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="sale">For Sale</option>
                    <option value="rent">For Rent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Location *</label>
                <input
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  placeholder="e.g. Beverly Hills, CA"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Bedrooms</label>
                  <input
                    type="number"
                    value={formData.bedrooms}
                    onChange={(e) => setFormData({...formData, bedrooms: e.target.value})}
                    placeholder="3"
                    min="0"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Bathrooms</label>
                  <input
                    type="number"
                    value={formData.bathrooms}
                    onChange={(e) => setFormData({...formData, bathrooms: e.target.value})}
                    placeholder="2"
                    min="0"
                    step="0.5"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Square Feet</label>
                  <input
                    type="number"
                    value={formData.sqft}
                    onChange={(e) => setFormData({...formData, sqft: e.target.value})}
                    placeholder="2000"
                    min="0"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Image URLs (comma separated)</label>
                <input
                  value={formData.images}
                  onChange={(e) => setFormData({...formData, images: e.target.value})}
                  placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-xl font-semibold hover:from-teal-700 hover:to-emerald-700 transition-all"
                >
                  {editingProperty ? 'Update Property' : 'Add Property'}
                </button>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-6 py-3 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl font-semibold hover:bg-gray-200 dark:hover:bg-gray-600 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;

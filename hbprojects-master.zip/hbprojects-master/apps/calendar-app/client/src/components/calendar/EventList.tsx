import type { CalendarEvent } from '../../types';
import { Trash2, Edit } from 'lucide-react';

interface EventListProps {
  events: CalendarEvent[];
  onEdit: (event: CalendarEvent) => void;
  onDelete: (event: CalendarEvent) => void;
}

export const EventList = ({ events, onEdit, onDelete }: EventListProps) => {
  if (events.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
        No events scheduled
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {events.map((event) => (
        <div
          key={event._id}
          className="p-3 bg-white dark:bg-gray-800 rounded-lg shadow border-l-4 hover:shadow-md transition-shadow"
          style={{ borderLeftColor: event.category?.color || '#3b82f6' }}
        >
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 dark:text-white">{event.title}</h4>
              {event.location && (
                <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1 mt-1">
                  📍 {event.location}
                </p>
              )}
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                {new Date(event.start).toLocaleString()} - {new Date(event.end).toLocaleString()}
              </p>
            </div>
            <div className="flex gap-1">
              <button
                onClick={() => onEdit(event)}
                className="p-1.5 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={() => onDelete(event)}
                className="p-1.5 text-gray-500 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/20 rounded"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

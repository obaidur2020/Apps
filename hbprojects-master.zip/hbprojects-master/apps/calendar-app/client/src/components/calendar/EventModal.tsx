import { useState, useEffect } from 'react';
import type { CalendarEvent, EventFormData } from '../../types';
import { CATEGORIES } from '../../types';
import { X, Calendar, Clock, MapPin, AlignLeft, Sun } from 'lucide-react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: EventFormData) => void;
  event?: CalendarEvent;
  date?: Date;
}

// Helper: Convert ISO date to date input format (YYYY-MM-DD)
const toDateString = (isoString: string): string => {
  const date = new Date(isoString);
  return format(date, 'yyyy-MM-dd');
};

// Helper: Convert ISO date to datetime-local input format (YYYY-MM-DDTHH:mm)
const toDateTimeString = (isoString: string): string => {
  const date = new Date(isoString);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
};

export const EventModal = ({ isOpen, onClose, onSave, event, date }: EventModalProps) => {
  const [formData, setFormData] = useState<EventFormData>({
    title: '',
    start: '',
    end: '',
    allDay: true,
    category: CATEGORIES[0],
  });

  // Initialize form when opening or event changes
  useEffect(() => {
    if (event) {
      setFormData({
        title: event.title,
        description: event.description,
        location: event.location,
        start: event.allDay ? toDateString(event.start) : toDateTimeString(event.start),
        end: event.allDay ? toDateString(event.end) : toDateTimeString(event.end),
        allDay: event.allDay,
        category: event.category,
      });
    } else if (date) {
      const dateStr = format(date, 'yyyy-MM-dd');
      setFormData({
        title: '',
        start: dateStr,
        end: dateStr,
        allDay: true,
        category: CATEGORIES[0],
      });
    }
  }, [event, date, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      toast.error('Title is required');
      return;
    }
    if (!formData.start || !formData.end) {
      toast.error('Start and end dates are required');
      return;
    }
    onSave(formData);
    onClose();
  };

  const handleAllDayToggle = (checked: boolean) => {
    // Convert dates based on new allDay setting - single update
    let newStart = formData.start;
    let newEnd = formData.end;

    if (formData.start) {
      if (checked) {
        // Switching to all-day: extract date portion
        newStart = formData.start.includes('T') ? formData.start.split('T')[0] : formData.start;
      } else {
        // Switching to timed: add default time
        newStart = formData.start.includes('T') ? formData.start : `${formData.start}T09:00`;
      }
    }

    if (formData.end) {
      if (checked) {
        // Switching to all-day: extract date portion
        newEnd = formData.end.includes('T') ? formData.end.split('T')[0] : formData.end;
      } else {
        // Switching to timed: add default time
        newEnd = formData.end.includes('T') ? formData.end : `${formData.end}T10:00`;
      }
    }

    setFormData({ ...formData, start: newStart, end: newEnd, allDay: checked });
  };

  // Helper to check if single day - simplified
  const isSingleDay = (): boolean => {
    if (!formData.start || !formData.end) return false;

    // Extract just the date portion (before 'T' if exists)
    const startDate = formData.start.includes('T') ? formData.start.split('T')[0] : formData.start;
    const endDate = formData.end.includes('T') ? formData.end.split('T')[0] : formData.end;

    return startDate === endDate;
  };

  const getEventDurationText = (): string => {
    if (!formData.start || !formData.end) return '';

    const startDate = formData.start.includes('T') ? formData.start.split('T')[0] : formData.start;
    const endDate = formData.end.includes('T') ? formData.end.split('T')[0] : formData.end;

    if (startDate === endDate) {
      return formData.allDay ? '📅 Single day event' : '📅 Single day (timed)';
    }

    if (formData.allDay) {
      return `📅 Multi-day: ${startDate} to ${endDate}`;
    }

    return '📅 Multi-day (timed)';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {event ? 'Edit Event' : 'New Event'}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 dark:text-gray-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div>
            <input
              type="text"
              placeholder="Event title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              autoFocus
            />
          </div>

          {/* All Day Toggle */}
          <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
            <button
              type="button"
              onClick={() => handleAllDayToggle(!formData.allDay)}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                formData.allDay ? 'bg-primary-600' : 'bg-gray-300 dark:bg-gray-600'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  formData.allDay ? 'left-7' : 'left-1'
                }`}
              />
            </button>
            <span className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Sun className="w-4 h-4" />
              All day
            </span>
          </div>

          {/* Date Inputs */}
          {formData.allDay ? (
            // All Day: Use date inputs for multi-day support
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Start Date
                </label>
                <input
                  type="date"
                  value={formData.start}
                  onChange={(e) => setFormData({ ...formData, start: e.target.value, end: formData.end && formData.end < e.target.value ? e.target.value : formData.end })}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  End Date
                </label>
                <input
                  type="date"
                  value={formData.end}
                  onChange={(e) => setFormData({ ...formData, end: e.target.value })}
                  min={formData.start}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {getEventDurationText()}
                </p>
              </div>
            </div>
          ) : (
            // Timed Event: Use datetime-local inputs
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  Start
                </label>
                <input
                  type="datetime-local"
                  value={formData.start}
                  onChange={(e) => setFormData({ ...formData, start: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  End
                </label>
                <input
                  type="datetime-local"
                  value={formData.end}
                  onChange={(e) => setFormData({ ...formData, end: e.target.value })}
                  min={formData.start}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {getEventDurationText()}
                </p>
              </div>
            </div>
          )}

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              Location
            </label>
            <input
              type="text"
              placeholder="Add location (optional)"
              value={formData.location || ''}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Category
            </label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.name}
                  type="button"
                  onClick={() => setFormData({ ...formData, category: cat })}
                  className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                    formData.category?.name === cat.name
                      ? 'ring-2 ring-offset-2 ring-offset-white dark:ring-offset-gray-800'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: cat.color,
                    color: 'white',
                    ringColor: cat.color,
                  }}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
              <AlignLeft className="w-4 h-4" />
              Description
            </label>
            <textarea
              placeholder="Add description (optional)"
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
            >
              Save Event
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import type { CalendarEvent } from '../../types';
import { format, isSameDay, isSameMonth, startOfDay, endOfDay } from 'date-fns';
import { Trash2, Edit } from 'lucide-react';

interface CalendarCellProps {
  date: Date;
  currentMonth: Date;
  events: CalendarEvent[];
  onClick: (date: Date) => void;
  onEditEvent?: (event: CalendarEvent) => void;
  onDeleteEvent?: (event: CalendarEvent) => void;
}

export const CalendarCell = ({ date, currentMonth, events, onClick, onEditEvent, onDeleteEvent }: CalendarCellProps) => {
  const isCurrentMonth = isSameMonth(date, currentMonth);
  const isToday = isSameDay(date, new Date());

  const dayEvents = events.filter((event) => {
    const eventStart = new Date(event.start);
    const eventEnd = new Date(event.end);
    return date >= startOfDay(eventStart) && date <= endOfDay(eventEnd);
  });

  return (
    <div
      onClick={() => onClick(date)}
      className={`min-h-28 p-2 border border-gray-200 dark:border-gray-700 ${
        !isCurrentMonth ? 'bg-gray-50 dark:bg-gray-800/50' : 'bg-white dark:bg-gray-800'
      } hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors cursor-pointer`}
    >
      <div
        className={`text-sm font-medium mb-1 ${
          isToday
            ? 'w-7 h-7 flex items-center justify-center bg-primary-600 text-white rounded-full'
            : isCurrentMonth
            ? 'text-gray-900 dark:text-white'
            : 'text-gray-400'
        }`}
      >
        {format(date, 'd')}
      </div>

      <div className="space-y-1">
        {dayEvents.slice(0, 3).map((event) => (
          <div
            key={event._id}
            onClick={(e) => e.stopPropagation()}
            className="text-xs p-1 rounded truncate flex items-center gap-1 group"
            style={{ backgroundColor: event.category?.color || '#3b82f6', color: 'white' }}
          >
            <span className="flex-1 truncate">{event.title}</span>
            <div className="hidden group-hover:flex gap-1">
              {onEditEvent && (
                <button
                  onClick={() => onEditEvent(event)}
                  className="hover:bg-white/20 p-0.5 rounded"
                >
                  <Edit className="w-3 h-3" />
                </button>
              )}
              {onDeleteEvent && (
                <button
                  onClick={() => onDeleteEvent(event)}
                  className="hover:bg-white/20 p-0.5 rounded"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        ))}
        {dayEvents.length > 3 && (
          <div className="text-xs text-gray-500 dark:text-gray-400 pl-1">
            +{dayEvents.length - 3} more
          </div>
        )}
      </div>
    </div>
  );
};

export interface CalendarEvent {
  _id: string;
  userId: string;
  title: string;
  description?: string;
  location?: string;
  start: string;
  end: string;
  allDay: boolean;
  recurrence?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    interval: number;
    until?: string;
  };
  category?: {
    name: string;
    color: string;
  };
  reminders: { minutes: number; sent: boolean }[];
  attendees: Array<{ email: string; status: string }>;
  createdAt: string;
  updatedAt: string;
}

export interface EventFormData {
  title: string;
  description?: string;
  location?: string;
  start: string;
  end: string;
  allDay: boolean;
  recurrence?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    interval: number;
    until?: string;
  };
  category?: {
    name: string;
    color: string;
  };
}

export const CATEGORIES = [
  { name: 'Work', color: '#3b82f6' },
  { name: 'Personal', color: '#22c55e' },
  { name: 'Meeting', color: '#f59e0b' },
  { name: 'Reminder', color: '#ef4444' },
  { name: 'Birthday', color: '#ec4899' },
  { name: 'Holiday', color: '#8b5cf6' },
];

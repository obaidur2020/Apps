import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { CalendarPage } from './pages/CalendarPage';
import './index.css';

function App() {
  return (
    <Router>
      <div className="min-h-screen">
        <Toaster position="top-right" />
        <Routes>
          <Route path="/" element={<CalendarPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

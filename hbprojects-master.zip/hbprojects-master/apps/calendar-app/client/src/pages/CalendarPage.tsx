import { useState, useEffect } from 'react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek, isSameDay } from 'date-fns';
import { CalendarHeader } from '../components/calendar/CalendarHeader';
import { CalendarCell } from '../components/calendar/CalendarCell';
import { EventModal } from '../components/calendar/EventModal';
import { EventList } from '../components/calendar/EventList';
import { Plus, Calendar as CalendarIcon } from 'lucide-react';
import { eventService } from '../services/eventService';
import type { CalendarEvent, EventFormData } from '../types';
import { CATEGORIES } from '../types';
import toast from 'react-hot-toast';

export const CalendarPage = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | undefined>();
  const [view, setView] = useState<'month' | 'list'>('month');

  useEffect(() => {
    loadEvents();
  }, [currentDate]);

  const loadEvents = async () => {
    try {
      const monthStart = startOfMonth(currentDate);
      const monthEnd = endOfMonth(currentDate);
      const data = await eventService.getEvents(monthStart.toISOString(), monthEnd.toISOString());
      setEvents(data);
    } catch (error) {
      console.error('Failed to load events');
    }
  };

  const calendarDays = eachDayOfInterval({
    start: startOfWeek(startOfMonth(currentDate)),
    end: endOfWeek(endOfMonth(currentDate)),
  });

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const handleDayClick = (date: Date) => {
    setSelectedDate(date);
    setEditingEvent(undefined);
    setModalOpen(true);
  };

  const handleSaveEvent = async (data: EventFormData) => {
    try {
      if (editingEvent) {
        await eventService.updateEvent(editingEvent._id, data);
        toast.success('Event updated');
      } else {
        await eventService.createEvent(data);
        toast.success('Event created');
      }
      loadEvents();
    } catch (error) {
      toast.error('Failed to save event');
    }
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setModalOpen(true);
  };

  const handleDeleteEvent = async (event: CalendarEvent) => {
    if (window.confirm('Delete this event?')) {
      try {
        await eventService.deleteEvent(event._id);
        toast.success('Event deleted');
        loadEvents();
      } catch (error) {
        toast.error('Failed to delete event');
      }
    }
  };

  const todaysEvents = events.filter((e) => isSameDay(new Date(e.start), new Date()));

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-6 h-6 text-primary-600" />
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Calendar</h1>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
          >
            <Plus className="w-4 h-4" />
            Add Event
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Calendar */}
          <div className="flex-1">
            <CalendarHeader
              currentDate={currentDate}
              onPrevMonth={() => setCurrentDate(subMonths(currentDate, 1))}
              onNextMonth={() => setCurrentDate(addMonths(currentDate, 1))}
              onToday={() => setCurrentDate(new Date())}
            />

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
              {/* Week day headers */}
              <div className="grid grid-cols-7 border-b dark:border-gray-700">
                {weekDays.map((day) => (
                  <div
                    key={day}
                    className="py-2 text-center text-sm font-medium text-gray-700 dark:text-gray-300"
                  >
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar grid */}
              <div className="grid grid-cols-7">
                {calendarDays.map((date, idx) => (
                  <CalendarCell
                    key={idx}
                    date={date}
                    currentMonth={currentDate}
                    events={events}
                    onClick={handleDayClick}
                    onEditEvent={handleEditEvent}
                    onDeleteEvent={handleDeleteEvent}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="w-80">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                {format(new Date(), 'EEEE, MMMM d')}
              </h3>
              <EventList
                events={todaysEvents}
                onEdit={handleEditEvent}
                onDelete={handleDeleteEvent}
              />
            </div>
          </aside>
        </div>
      </main>

      <EventModal
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setEditingEvent(undefined);
        }}
        onSave={handleSaveEvent}
        event={editingEvent}
        date={selectedDate || undefined}
      />
    </div>
  );
};

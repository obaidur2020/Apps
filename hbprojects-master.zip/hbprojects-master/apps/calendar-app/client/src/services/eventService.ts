import api from './api';
import type { CalendarEvent, EventFormData } from '../types';

export const eventService = {
  async getEvents(start?: string, end?: string): Promise<CalendarEvent[]> {
    const params: Record<string, string> = {};
    if (start) params.start = start;
    if (end) params.end = end;

    const response = await api.get<{ success: boolean; data: { events: CalendarEvent[] } }>(
      '/events',
      { params }
    );
    return response.data.data!.events;
  },

  async createEvent(data: EventFormData): Promise<CalendarEvent> {
    const response = await api.post<{ success: boolean; data: { event: CalendarEvent } }>(
      '/events',
      data
    );
    return response.data.data!.event;
  },

  async updateEvent(id: string, data: Partial<EventFormData>): Promise<CalendarEvent> {
    const response = await api.put<{ success: boolean; data: { event: CalendarEvent } }>(
      `/events/${id}`,
      data
    );
    return response.data.data!.event;
  },

  async deleteEvent(id: string): Promise<void> {
    await api.delete(`/events/${id}`);
  },
};

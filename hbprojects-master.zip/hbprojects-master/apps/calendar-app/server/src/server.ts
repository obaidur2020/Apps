import express, { Application, Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB from './config/db';
import eventRoutes from './routes/events';

dotenv.config();
connectDB();

const app: Application = express();
const PORT = process.env.PORT || 5002;

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5175', credentials: true }));
app.use(express.json());

app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({ status: 'OK', message: 'Calendar Server running' });
});

app.use('/api/events', eventRoutes);

app.listen(PORT, () => console.log(`Calendar Server running on port ${PORT}`));

export default app;

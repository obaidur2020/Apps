import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IEventReminder {
  minutes: number;
  sent: boolean;
}

export interface IEventAttendee {
  userId?: Types.ObjectId;
  email: string;
  status: 'pending' | 'accepted' | 'declined';
}

export interface IEventRecurrence {
  frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
  interval: number;
  until?: Date;
  count?: number;
}

export interface IEventCategory {
  name: string;
  color: string;
}

export interface IEvent extends Document {
  userId: Types.ObjectId;
  title: string;
  description?: string;
  location?: string;
  start: Date;
  end: Date;
  allDay: boolean;
  recurrence?: IEventRecurrence;
  category?: IEventCategory;
  reminders: IEventReminder[];
  attendees: IEventAttendee[];
  googleEventId?: string;
  createdAt: Date;
  updatedAt: Date;
}

const ReminderSchema = new Schema<IEventReminder>({
  minutes: { type: Number, required: true },
  sent: { type: Boolean, default: false },
});

const AttendeeSchema = new Schema<IEventAttendee>({
  userId: { type: Schema.Types.ObjectId, ref: 'User' },
  email: { type: String, required: true },
  status: { type: String, enum: ['pending', 'accepted', 'declined'], default: 'pending' },
});

const CategorySchema = new Schema<IEventCategory>({
  name: { type: String, required: true },
  color: { type: String, required: true },
});

const RecurrenceSchema = new Schema<IEventRecurrence>({
  frequency: { type: String, enum: ['daily', 'weekly', 'monthly', 'yearly'], required: true },
  interval: { type: Number, default: 1 },
  until: { type: Date },
  count: { type: Number },
});

const EventSchema = new Schema<IEvent>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true },
    description: String,
    location: String,
    start: { type: Date, required: true, index: true },
    end: { type: Date, required: true },
    allDay: { type: Boolean, default: false },
    recurrence: RecurrenceSchema,
    category: CategorySchema,
    reminders: [ReminderSchema],
    attendees: [AttendeeSchema],
    googleEventId: String,
  },
  { timestamps: true }
);

// Compound index for date range queries
EventSchema.index({ userId: 1, start: 1, end: 1 });

export default mongoose.model<IEvent>('Event', EventSchema);

import { Response } from 'express';
import Event, { IEvent } from '../models/Event';
import { AuthRequest } from '../middleware/auth';
import { rrulestr, RRule } from 'rrule';
import type { FilterQuery } from 'mongoose';

export const getEvents = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { start, end } = req.query;

    const filter: FilterQuery<IEvent> = { userId: req.user.userId };

    if (start && end) {
      const queryStart = new Date(start as string);
      const queryEnd = new Date(end as string);

      // Include events that overlap with the date range:
      // - Events that start within the range
      // - Events that end within the range
      // - Events that span the entire range
      filter.$or = [
        { start: { $gte: queryStart, $lte: queryEnd } },
        { end: { $gte: queryStart, $lte: queryEnd } },
        { start: { $lte: queryStart }, end: { $gte: queryEnd } }
      ];
    }

    const events = await Event.find(filter).sort({ start: 1 }).lean();

    res.status(200).json({ success: true, data: { events } });
  } catch (error) {
    console.error('Get events error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

export const createEvent = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { title, description, location, start, end, allDay, recurrence, category, reminders } = req.body;

    const event = await Event.create({
      userId: req.user.userId,
      title,
      description,
      location,
      start: new Date(start),
      end: new Date(end),
      allDay: allDay || false,
      recurrence,
      category,
      reminders: reminders || [],
    });

    res.status(201).json({ success: true, data: { event } });
  } catch (error) {
    console.error('Create event error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

export const updateEvent = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const event = await Event.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      req.body,
      { new: true }
    );

    if (!event) {
      res.status(404).json({ success: false, error: { message: 'Event not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { event } });
  } catch (error) {
    console.error('Update event error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

export const deleteEvent = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const event = await Event.findOneAndDelete({
      _id: req.params.id,
      userId: req.user.userId,
    });

    if (!event) {
      res.status(404).json({ success: false, error: { message: 'Event not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { message: 'Event deleted' } });
  } catch (error) {
    console.error('Delete event error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

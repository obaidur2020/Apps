import { Request, Response, NextFunction } from 'express';

export interface AuthRequest extends Request {
  user?: { userId: string; email: string };
}

// Demo user ID - valid 24-character hex string (MongoDB ObjectId format)
const DEMO_USER_ID = '000000000000000000000001';

export const auth = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, error: { message: 'No token provided' } });
    return;
  }

  // Demo mode - use a valid ObjectId
  req.user = { userId: DEMO_USER_ID, email: 'demo@example.com' };
  next();
};

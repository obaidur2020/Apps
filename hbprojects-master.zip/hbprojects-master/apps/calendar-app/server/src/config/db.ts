import mongoose from 'mongoose';

const connectDB = async (): Promise<void> => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/calendar-app');
    console.log('MongoDB Connected');
  } catch (error) {
    if (error instanceof Error) console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;

# Calendar App

A full-stack calendar application with event management, multiple views, and reminders.

## 🚀 Quick Start

```bash
docker-compose up -d
```

## 🌐 Access

- **Frontend**: http://localhost:5174
- **Backend API**: http://localhost:5002
- **Health Check**: http://localhost:5002/health

## ✨ Features

- Monthly, weekly, and daily views
- Create, edit, and delete events
- Single-day and multi-day events
- All-day and timed events
- Event categories with colors
- Recurring events
- Dark mode support
- Responsive design

## 🔧 Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript, MongoDB
- **Database**: MongoDB

## 📁 Structure

```
calendar-app/
├── client/          # React frontend
│   └── src/
│       ├── components/
│       │   └── calendar/
│       ├── pages/
│       └── hooks/
└── server/          # Express backend
    └── src/
        ├── models/
        ├── routes/
        └── controllers/
```

## 🐳 Docker Services

- `calendar-app-server` - Backend API (port 5002)
- `calendar-app-client` - Frontend UI (port 5174)

## 📝 API Endpoints

- `GET /api/events` - Get all events
- `POST /api/events` - Create event
- `GET /api/events/:id` - Get event by ID
- `PUT /api/events/:id` - Update event
- `DELETE /api/events/:id` - Delete event

import axios from 'axios';

const api = axios.create({ baseURL: 'http://localhost:5003/api' });

api.interceptors.request.use((c) => {
  c.headers.Authorization = `Bearer ${localStorage.getItem('token') || 'demo'}`;
  return c;
});

interface CreateSnippetData {
  title: string;
  code: string;
  language: string;
  description?: string;
  tags?: string[];
  isPublic?: boolean;
}

interface SnippetFilters {
  language?: string;
  tags?: string;
  search?: string;
}

export const snippetService = {
  async getSnippets(filters: SnippetFilters = {}) {
    return (await api.get('/snippets', { params: filters })).data.data;
  },
  async createSnippet(data: CreateSnippetData) {
    return (await api.post('/snippets', data)).data.data;
  },
  async deleteSnippet(id: string) {
    return (await api.delete(`/snippets/${id}`)).data;
  },
  async rateSnippet(id: string, rating: number) {
    return (await api.post(`/snippets/${id}/rate`, { rating })).data.data;
  },
  async forkSnippet(id: string) {
    return (await api.post(`/snippets/${id}/fork`)).data.data;
  },
};

import { useState, useEffect } from 'react';
import { snippetService } from '../services/api';
import type { Snippet } from '../types';
import { LANGUAGES } from '../types';
import { Search, Plus, Code, Copy, Check, X, Tag, Eye, Heart, Sparkles, Zap, ChevronRight, TrendingUp } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Prism from 'prismjs';
import 'prismjs/themes/prism-tomorrow.css';

const LANGUAGE_COLORS: Record<string, { bg: string; text: string; gradient: string }> = {
  'JavaScript': { bg: 'bg-yellow-400/20', text: 'text-yellow-600', gradient: 'from-yellow-400 to-orange-500' },
  'TypeScript': { bg: 'bg-blue-400/20', text: 'text-blue-600', gradient: 'from-blue-400 to-blue-600' },
  'Python': { bg: 'bg-green-400/20', text: 'text-green-600', gradient: 'from-green-400 to-emerald-600' },
  'Java': { bg: 'bg-red-400/20', text: 'text-red-600', gradient: 'from-red-400 to-red-600' },
  'C++': { bg: 'bg-blue-500/20', text: 'text-blue-700', gradient: 'from-blue-500 to-blue-700' },
  'C#': { bg: 'bg-purple-400/20', text: 'text-purple-600', gradient: 'from-purple-400 to-purple-600' },
  'Go': { bg: 'bg-cyan-400/20', text: 'text-cyan-600', gradient: 'from-cyan-400 to-cyan-600' },
  'Rust': { bg: 'bg-orange-400/20', text: 'text-orange-600', gradient: 'from-orange-400 to-orange-600' },
  'PHP': { bg: 'bg-indigo-400/20', text: 'text-indigo-600', gradient: 'from-indigo-400 to-indigo-600' },
  'Ruby': { bg: 'bg-red-500/20', text: 'text-red-600', gradient: 'from-red-500 to-red-700' },
  'Swift': { bg: 'bg-orange-500/20', text: 'text-orange-600', gradient: 'from-orange-500 to-orange-700' },
  'Kotlin': { bg: 'bg-violet-400/20', text: 'text-violet-600', gradient: 'from-violet-400 to-violet-600' },
};

const formatDistanceToNow = (date: Date): string => {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
};

export default function SnippetsPage() {
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [filtered, setFiltered] = useState<Snippet[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedSnippet, setSelectedSnippet] = useState<Snippet | null>(null);
  const [newSnippet, setNewSnippet] = useState({
    title: '',
    code: '',
    language: LANGUAGES[0],
    description: '',
    tags: [] as string[]
  });
  const [search, setSearch] = useState('');
  const [selectedLang, setSelectedLang] = useState('');
  const [selectedTag, setSelectedTag] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    loadSnippets();
  }, []);

  useEffect(() => {
    let result = snippets;
    if (search) {
      result = result.filter(s =>
        s.title.toLowerCase().includes(search.toLowerCase()) ||
        s.code.toLowerCase().includes(search.toLowerCase()) ||
        s.description?.toLowerCase().includes(search.toLowerCase())
      );
    }
    if (selectedLang) result = result.filter(s => s.language === selectedLang);
    if (selectedTag) result = result.filter(s => s.tags.includes(selectedTag));
    setFiltered(result);
  }, [search, selectedLang, selectedTag, snippets]);

  useEffect(() => {
    Prism.highlightAll();
  }, [selectedSnippet, modalOpen]);

  const loadSnippets = async () => {
    const data = await snippetService.getSnippets();
    setSnippets(data.snippets);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await snippetService.createSnippet(newSnippet);
    setModalOpen(false);
    setNewSnippet({ title: '', code: '', language: LANGUAGES[0], description: '', tags: [] });
    loadSnippets();
    toast.success('Snippet created!');
  };

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    toast.success('Code copied!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this snippet?')) {
      await snippetService.deleteSnippet(id);
      loadSnippets();
      toast.success('Snippet deleted!');
    }
  };

  const getAllTags = () => {
    const tags = new Set<string>();
    snippets.forEach(s => s.tags.forEach(t => tags.add(t)));
    return Array.from(tags);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Animated background pattern */}
      <div className="fixed inset-0 opacity-30">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-900/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-5">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-xl blur-lg opacity-50 animate-pulse"></div>
                <div className="relative w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-violet-500/30">
                  <Code className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Code Snippets</h1>
                <p className="text-sm text-slate-400">{snippets.length} snippets saved</p>
              </div>
            </div>
            <button
              onClick={() => setModalOpen(true)}
              className="group relative px-6 py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-medium rounded-xl overflow-hidden transition-all hover:scale-105 hover:shadow-xl hover:shadow-violet-500/30"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform"></div>
              <span className="relative flex items-center gap-2">
                <Plus className="w-5 h-5" /> New Snippet
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <Code className="w-5 h-5 text-violet-400" />
              <span className="text-xs text-violet-400 bg-violet-500/10 px-2 py-1 rounded-full">Total</span>
            </div>
            <p className="text-3xl font-bold text-white">{snippets.length}</p>
            <p className="text-xs text-slate-400 mt-1">All snippets</p>
          </div>
          <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <Tag className="w-5 h-5 text-blue-400" />
              <span className="text-xs text-blue-400 bg-blue-500/10 px-2 py-1 rounded-full">Languages</span>
            </div>
            <p className="text-3xl font-bold text-white">{new Set(snippets.map(s => s.language)).size}</p>
            <p className="text-xs text-slate-400 mt-1">Unique languages</p>
          </div>
          <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">Tags</span>
            </div>
            <p className="text-3xl font-bold text-white">{getAllTags().length}</p>
            <p className="text-xs text-slate-400 mt-1">Categories</p>
          </div>
          <div className="bg-gradient-to-br from-orange-500/10 to-amber-500/10 border border-orange-500/20 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <Zap className="w-5 h-5 text-orange-400" />
              <span className="text-xs text-orange-400 bg-orange-500/10 px-2 py-1 rounded-full">Activity</span>
            </div>
            <p className="text-3xl font-bold text-white">{snippets.reduce((a, s) => a + s.stats.views, 0)}</p>
            <p className="text-xs text-slate-400 mt-1">Total views</p>
          </div>
        </div>

        {/* Search & Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search snippets..."
                className="w-full pl-12 pr-4 py-4 bg-slate-800/50 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
              />
            </div>
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value)}
              className="px-5 py-4 bg-slate-800/50 border border-slate-700 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all appearance-none cursor-pointer"
            >
              <option value="">All Languages</option>
              {LANGUAGES.map(l => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>

          {/* Tags */}
          {getAllTags().length > 0 && (
            <div className="flex items-center gap-3 flex-wrap">
              <Tag className="w-4 h-4 text-slate-400" />
              <button
                onClick={() => setSelectedTag('')}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${!selectedTag
                  ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-violet-500/30'
                  : 'bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
              >
                All
              </button>
              {getAllTags().map(tag => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${selectedTag === tag
                    ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-violet-500/30'
                    : 'bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700'
                    }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Snippets Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-24">
            <div className="relative w-24 h-24 mx-auto mb-8">
              <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-3xl blur-2xl opacity-30"></div>
              <div className="relative bg-slate-800 rounded-3xl flex items-center justify-center">
                <Code className="w-10 h-10 text-violet-400" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">No snippets yet</h3>
            <p className="text-slate-400 mb-8 max-w-md mx-auto">Create your first code snippet and start building your personal library</p>
            <button
              onClick={() => setModalOpen(true)}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-medium rounded-2xl hover:scale-105 transition-all shadow-xl shadow-violet-500/30"
            >
              <Plus className="w-5 h-5" /> Create Your First Snippet
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((s, index) => {
              const colors = LANGUAGE_COLORS[s.language] || { bg: 'bg-slate-500/20', text: 'text-slate-400', gradient: 'from-slate-400 to-slate-600' };
              return (
                <div
                  key={s._id}
                  className="group relative bg-slate-900/50 border border-slate-800 hover:border-violet-500/50 rounded-3xl overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-violet-500/10 hover:-translate-y-1"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  {/* Hover glow effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-violet-500/5 to-fuchsia-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>

                  {/* Card Header */}
                  <div className="relative p-6 pb-4">
                    <div className="flex items-start justify-between mb-4">
                      <div
                        className={`px-3 py-1.5 rounded-xl text-sm font-bold ${colors.bg} ${colors.text} bg-gradient-to-r ${colors.gradient}`}
                      >
                        {s.language}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedSnippet(s)}
                          className="p-2.5 bg-slate-800 hover:bg-violet-500/20 text-slate-400 hover:text-violet-400 rounded-xl transition-all"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(s._id)}
                          className="p-2.5 bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 rounded-xl transition-all"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-white mb-2 line-clamp-1">{s.title}</h3>
                    {s.description && (
                      <p className="text-sm text-slate-400 line-clamp-2 mb-4">{s.description}</p>
                    )}

                    {/* Tags */}
                    {s.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {s.tags.slice(0, 3).map(tag => (
                          <span key={tag} className="px-2.5 py-1 bg-violet-500/10 text-violet-400 text-xs rounded-full border border-violet-500/20">
                            #{tag}
                          </span>
                        ))}
                        {s.tags.length > 3 && (
                          <span className="px-2.5 py-1 bg-slate-800 text-slate-500 text-xs rounded-full border border-slate-700">
                            +{s.tags.length - 3}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Code Preview */}
                  <div className="relative mx-4 mb-4 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800">
                    <div className="p-4 max-h-48 overflow-hidden">
                      <pre className="text-xs"><code className={`language-${s.language.toLowerCase()}`}>{s.code.slice(0, 150)}...</code></pre>
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/50 to-slate-950"></div>
                    </div>
                    <button
                      onClick={() => handleCopy(s.code, s._id)}
                      className="absolute top-3 right-3 p-2.5 bg-slate-800 hover:bg-violet-500 rounded-xl transition-all group/border:opacity-0 group-hover:opacity-100"
                    >
                      {copiedId === s._id ? (
                        <Check className="w-4 h-4 text-green-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors" />
                      )}
                    </button>
                  </div>

                  {/* Card Footer */}
                  <div className="relative px-6 py-4 border-t border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm text-slate-400">
                      <span className="flex items-center gap-1.5 hover:text-violet-400 transition-colors">
                        <Eye className="w-4 h-4" /> {s.stats.views}
                      </span>
                      <span className="flex items-center gap-1.5 hover:text-violet-400 transition-colors">
                        <Heart className="w-4 h-4" /> {s.stats.forks}
                      </span>
                    </div>
                    <span className="text-xs text-slate-500">
                      {formatDistanceToNow(new Date(s.createdAt))}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Create Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModalOpen(false)}></div>
          <div className="relative bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl shadow-violet-500/20 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <form onSubmit={handleSubmit} className="p-8">
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-violet-500/30">
                    <Plus className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">Create New Snippet</h2>
                    <p className="text-sm text-slate-400">Save your code for later</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-3">Title</label>
                    <input
                      value={newSnippet.title}
                      onChange={(e) => setNewSnippet({ ...newSnippet, title: e.target.value })}
                      placeholder="e.g., React useEffect Hook"
                      className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-3">Language</label>
                    <select
                      value={newSnippet.language}
                      onChange={(e) => setNewSnippet({ ...newSnippet, language: e.target.value })}
                      className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all appearance-none cursor-pointer"
                    >
                      {LANGUAGES.map(l => (
                        <option key={l} value={l}>{l}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-3">Code</label>
                  <textarea
                    value={newSnippet.code}
                    onChange={(e) => setNewSnippet({ ...newSnippet, code: e.target.value })}
                    placeholder="Paste your code here..."
                    className="w-full px-5 py-4 bg-slate-950 text-gray-100 rounded-2xl font-mono text-sm border border-slate-800 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                    rows={14}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-3">Description</label>
                  <textarea
                    value={newSnippet.description}
                    onChange={(e) => setNewSnippet({ ...newSnippet, description: e.target.value })}
                    placeholder="What does this snippet do?"
                    className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-3">Tags (comma-separated)</label>
                  <input
                    value={newSnippet.tags.join(', ')}
                    onChange={(e) => setNewSnippet({ ...newSnippet, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) })}
                    placeholder="e.g., react, hooks, frontend"
                    className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="submit"
                    className="flex-1 py-4 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-medium rounded-2xl hover:scale-[1.02] transition-all shadow-xl shadow-violet-500/30 flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-5 h-5" /> Create Snippet
                  </button>
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-8 py-4 bg-slate-800 text-slate-300 font-medium rounded-2xl hover:bg-slate-700 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Snippet Modal */}
      {selectedSnippet && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setSelectedSnippet(null)}></div>
          <div className="relative bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl shadow-violet-500/20 w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-800">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className={`px-4 py-2 rounded-xl text-sm font-bold text-white bg-gradient-to-r ${LANGUAGE_COLORS[selectedSnippet.language]?.gradient || 'from-slate-400 to-slate-600'}`}
                    >
                      {selectedSnippet.language}
                    </div>
                    <h2 className="text-2xl font-bold text-white">{selectedSnippet.title}</h2>
                  </div>
                  {selectedSnippet.description && (
                    <p className="text-slate-400">{selectedSnippet.description}</p>
                  )}
                  {selectedSnippet.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {selectedSnippet.tags.map(tag => (
                        <span key={tag} className="px-3 py-1.5 bg-violet-500/10 text-violet-400 text-sm rounded-full border border-violet-500/20">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => setSelectedSnippet(null)}
                  className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            {/* Code Display */}
            <div className="flex-1 p-6 overflow-y-auto">
              <div className="relative">
                <div className="absolute top-4 right-4 z-10">
                  <button
                    onClick={() => handleCopy(selectedSnippet.code, selectedSnippet._id)}
                    className="p-3 bg-slate-800 hover:bg-violet-600 rounded-xl transition-all flex items-center gap-2"
                  >
                    {copiedId === selectedSnippet._id ? (
                      <>
                        <Check className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-green-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-400">Copy code</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="bg-slate-950 p-6 rounded-2xl overflow-x-auto border border-slate-800">
                  <code className={`language-${selectedSnippet.language.toLowerCase()} text-sm`}>{selectedSnippet.code}</code>
                </pre>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-6 border-t border-slate-800 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-6 text-sm text-slate-400">
                <span className="flex items-center gap-2"><Eye className="w-5 h-5" /> {selectedSnippet.stats.views} views</span>
                <span className="flex items-center gap-2"><Heart className="w-5 h-5" /> {selectedSnippet.stats.forks} forks</span>
                <span className="flex items-center gap-2"><TrendingUp className="w-5 h-5" /> {selectedSnippet.stats.avgRating.toFixed(1)} rating</span>
              </div>
              <span className="text-sm text-slate-500">
                {formatDistanceToNow(new Date(selectedSnippet.createdAt))}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import SnippetsPage from './pages/SnippetsPage';
import './index.css';

function App() {
  return <SnippetsPage />;
}

export default App;

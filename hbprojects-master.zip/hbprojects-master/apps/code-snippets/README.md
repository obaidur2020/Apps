# Code Snippets

A full-stack code snippet repository with syntax highlighting and organization features.

## 🚀 Quick Start

```bash
docker-compose up -d
```

## 🌐 Access

- **Frontend**: http://localhost:5175
- **Backend API**: http://localhost:5003
- **Health Check**: http://localhost:5003/health

## ✨ Features

- Create, edit, and delete code snippets
- Syntax highlighting for multiple languages
- Language filtering
- Tag system
- Rating system
- Fork snippets
- Search functionality
- Dark mode support
- Modern glassmorphism UI

## 🔧 Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript, MongoDB
- **Database**: MongoDB

## 📁 Structure

```
code-snippets/
├── client/          # React frontend
│   └── src/
│       ├── components/
│       ├── pages/
│       └── services/
└── server/          # Express backend
    └── src/
        ├── models/
        ├── routes/
        └── controllers/
```

## 🐳 Docker Services

- `code-snippets-server` - Backend API (port 5003)
- `code-snippets-client` - Frontend UI (port 5175)

## 📝 API Endpoints

- `GET /api/snippets` - Get all snippets
- `POST /api/snippets` - Create snippet
- `GET /api/snippets/:id` - Get snippet by ID
- `PUT /api/snippets/:id` - Update snippet
- `DELETE /api/snippets/:id` - Delete snippet
- `POST /api/snippets/:id/fork` - Fork snippet

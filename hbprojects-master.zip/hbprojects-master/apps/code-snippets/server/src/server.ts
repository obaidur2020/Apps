import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB from './config/db';
import snippetRoutes from './routes/snippets';

dotenv.config();
connectDB();

const app = express();
const PORT = process.env.PORT || 5003;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5175';

app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'OK' }));
app.use('/api/snippets', snippetRoutes);

app.listen(PORT, () => console.log(`Snippets Server running on port ${PORT}`));

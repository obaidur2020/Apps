import { Response } from 'express';
import mongoose from 'mongoose';
import Snippet, { ISnippet } from '../models/Snippet';
import { AuthRequest } from '../middleware/auth';
import type { FilterQuery } from 'mongoose';

export const getSnippets = async (req: AuthRequest, res: Response): Promise<void> => {
  const { language, tags, search } = req.query;
  const filter: FilterQuery<ISnippet> = { isPublic: true };

  if (language) filter.language = language;
  if (tags) filter.tags = { $in: (tags as string).split(',') };
  if (search) {
    filter.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
      { code: { $regex: search, $options: 'i' } },
    ];
  }

  const snippets = await Snippet.find(filter)
    .sort({ createdAt: -1 })
    .lean();

  res.json({ success: true, data: { snippets } });
};

export const createSnippet = async (req: AuthRequest, res: Response): Promise<void> => {
  if (!req.user) {
    res.status(401).json({ success: false, error: { message: 'Unauthorized' } });
    return;
  }

  const { title, description, code, language, tags } = req.body;
  const snippet = await Snippet.create({
    userId: req.user.userId,
    title,
    description,
    code,
    language,
    tags: tags || [],
  });

  res.status(201).json({ success: true, data: { snippet } });
};

export const deleteSnippet = async (req: AuthRequest, res: Response): Promise<void> => {
  if (!req.user) {
    res.status(401).json({ success: false, error: { message: 'Unauthorized' } });
    return;
  }

  await Snippet.findOneAndDelete({ _id: req.params.id, userId: req.user.userId });
  res.json({ success: true, data: { message: 'Deleted' } });
};

export const rateSnippet = async (req: AuthRequest, res: Response): Promise<void> => {
  const { rating } = req.body;
  const snippet = await Snippet.findById(req.params.id);

  if (!snippet) {
    res.status(404).json({ success: false, error: { message: 'Not found' } });
    return;
  }

  snippet.stats.ratings.push(rating);
  snippet.stats.avgRating = snippet.stats.ratings.reduce((a, b) => a + b, 0) / snippet.stats.ratings.length;
  await snippet.save();

  res.json({ success: true, data: { avgRating: snippet.stats.avgRating } });
};

export const addComment = async (req: AuthRequest, res: Response): Promise<void> => {
  if (!req.user) {
    res.status(401).json({ success: false, error: { message: 'Unauthorized' } });
    return;
  }

  const { content } = req.body;
  const snippet = await Snippet.findById(req.params.id);

  if (!snippet) {
    res.status(404).json({ success: false, error: { message: 'Not found' } });
    return;
  }

  snippet.comments.push({ userId: new mongoose.Types.ObjectId(req.user.userId), content, createdAt: new Date() });
  await snippet.save();

  res.json({ success: true, data: { comment: snippet.comments[snippet.comments.length - 1] } });
};

export const forkSnippet = async (req: AuthRequest, res: Response): Promise<void> => {
  if (!req.user) {
    res.status(401).json({ success: false, error: { message: 'Unauthorized' } });
    return;
  }

  const original = await Snippet.findById(req.params.id);
  if (!original) {
    res.status(404).json({ success: false, error: { message: 'Not found' } });
    return;
  }

  const snippet = await Snippet.create({
    userId: req.user.userId,
    title: `${original.title} (Fork)`,
    description: original.description,
    code: original.code,
    language: original.language,
    tags: original.tags,
    forkedFrom: original._id,
  });

  original.stats.forks++;
  await original.save();

  res.status(201).json({ success: true, data: { snippet } });
};

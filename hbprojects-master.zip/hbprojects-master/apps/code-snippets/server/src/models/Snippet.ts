import mongoose, { Document, Schema, Types } from 'mongoose';

export interface ISnippet extends Document {
  userId: Types.ObjectId;
  title: string;
  description: string;
  code: string;
  language: string;
  tags: string[];
  isPublic: boolean;
  forkedFrom?: Types.ObjectId;
  stats: {
    views: number;
    forks: number;
    ratings: number[];
    avgRating: number;
  };
  comments: Array<{
    userId: Types.ObjectId;
    content: string;
    createdAt: Date;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

const SnippetSchema = new Schema<ISnippet>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true },
    description: String,
    code: { type: String, required: true },
    language: { type: String, required: true },
    tags: [String],
    isPublic: { type: Boolean, default: true },
    forkedFrom: { type: Schema.Types.ObjectId, ref: 'Snippet' },
    stats: {
      views: { type: Number, default: 0 },
      forks: { type: Number, default: 0 },
      ratings: [Number],
      avgRating: { type: Number, default: 0 },
    },
    comments: [{
      userId: { type: Schema.Types.ObjectId, ref: 'User' },
      content: String,
      createdAt: { type: Date, default: Date.now },
    }],
  },
  { timestamps: true }
);

SnippetSchema.index({ language: 1, tags: 1 });
SnippetSchema.index({ isPublic: 1 });

export default mongoose.model<ISnippet>('Snippet', SnippetSchema);

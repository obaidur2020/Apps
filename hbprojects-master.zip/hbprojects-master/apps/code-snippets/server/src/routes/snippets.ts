import { Router } from 'express';
import { getSnippets, createSnippet, deleteSnippet, rateSnippet, addComment, forkSnippet } from '../controllers/snippetController';
import { auth } from '../middleware/auth';

const router = Router();

router.get('/', getSnippets);
router.post('/', auth, createSnippet);
router.delete('/:id', auth, deleteSnippet);
router.post('/:id/rate', rateSnippet);
router.post('/:id/comments', auth, addComment);
router.post('/:id/fork', auth, forkSnippet);

export default router;

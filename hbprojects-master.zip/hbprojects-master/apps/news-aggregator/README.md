# News Aggregator Website

A modern news aggregation application built with the MERN stack (MongoDB, Express, React, Node.js) that fetches real-time news from NewsAPI.

## 🚀 Quick Start with Docker

```bash
docker-compose up -d
```

### Access
- **Frontend**: http://localhost:5177
- **Backend API**: http://localhost:5001

### Demo Mode
The app runs in demo mode without an API key. Add `NEWS_API_KEY` to `server/.env` for real news (get free at https://newsapi.org/)

## Features

- **Real-time News** - Fetches latest news from NewsAPI
- **Category Filtering** - Browse by Business, Entertainment, General, Health, Science, Sports, Technology
- **Search** - Full-text search across all news articles
- **Bookmarks** - Save articles for later reading
- **Responsive Design** - Works on desktop and mobile
- **Dark/Light Theme** - Toggle between themes

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite
- Tailwind CSS
- React Router DOM
- Axios
- date-fns
- lucide-react

### Backend
- Node.js with Express
- TypeScript
- MongoDB with Mongoose
- Axios (for NewsAPI)

## Project Structure

```
apps/news-aggregator/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── pages/         # Page components
│   │   ├── services/      # API services
│   │   └── types/         # TypeScript types
│   └── ...
└── server/                # Express backend
    ├── src/
    │   ├── config/        # Configuration
    │   ├── controllers/   # Route controllers
    │   ├── middleware/    # Express middleware
    │   ├── models/        # Mongoose models
    │   ├── routes/        # API routes
    │   └── services/      # External API clients
    └── ...
```

## Getting Started

### Prerequisites

- Node.js 18+
- MongoDB (local or MongoDB Atlas)
- NewsAPI key (free at https://newsapi.org/)

### Installation

1. **Get a NewsAPI Key:**
   - Visit https://newsapi.org/
   - Register for a free account
   - Get your API key

2. **Install and run backend:**
```bash
cd server
npm install
cp .env.example .env
# Update .env with your NEWS_API_KEY
npm run dev
```

3. **Install and run frontend:**
```bash
cd client
npm install
npm run dev
```

4. **Open your browser** to `http://localhost:5174`

## Environment Variables

**Server (.env):**
```env
PORT=5001
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/news-aggregator
NEWS_API_KEY=your_news_api_key_here
CLIENT_URL=http://localhost:5174
```

**Client (.env):**
```env
VITE_API_URL=http://localhost:5001
```

## API Endpoints

### News
- `GET /api/news/headlines` - Get top headlines (category, country, sources, q, pageSize, page)
- `GET /api/news/everything` - Search all news (q, sources, from, to, language, sortBy, pageSize, page)
- `GET /api/news/sources` - Get available sources
- `GET /api/news/categories` - Get news categories

### Bookmarks (requires auth)
- `GET /api/bookmarks` - Get user's bookmarks
- `POST /api/bookmarks` - Create bookmark
- `DELETE /api/bookmarks/:id` - Delete bookmark
- `PATCH /api/bookmarks/:id` - Update bookmark notes

### Saved Searches (requires auth)
- `GET /api/saved-searches` - Get saved searches
- `POST /api/saved-searches` - Create saved search
- `DELETE /api/saved-searches/:id` - Delete saved search

## Usage

1. **Browse by Category** - Click category tabs to filter news
2. **Search** - Use the search bar to find specific topics
3. **Bookmark Articles** - Click the bookmark icon to save for later
4. **View Bookmarks** - Navigate to Bookmarks page to read saved articles

## License

MIT

export interface NewsArticle {
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  source: { id: string | null; name: string };
  author: string;
  publishedAt: string;
  content: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export interface NewsSource {
  id: string;
  name: string;
  category: string;
  country: string;
}

export interface Bookmark {
  _id: string;
  userId: string;
  articleId: string;
  articleData: {
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    source: { id: string | null; name: string };
    author: string;
    publishedAt: string;
  };
  notes?: string;
  createdAt: string;
}

export interface SavedSearch {
  _id: string;
  userId: string;
  name: string;
  query: string;
  filters: {
    category?: string;
    source?: string;
    from?: string;
    to?: string;
  };
  createdAt: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    message: string;
  };
}

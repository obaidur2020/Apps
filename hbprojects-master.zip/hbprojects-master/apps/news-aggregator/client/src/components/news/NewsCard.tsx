import type { NewsArticle } from '../../types';
import { ExternalLink, Clock, Bookmark } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useState } from 'react';
import toast from 'react-hot-toast';

interface NewsCardProps {
  article: NewsArticle;
  onBookmark?: (article: NewsArticle) => void;
  isBookmarked?: boolean;
}

export const NewsCard = ({ article, onBookmark, isBookmarked = false }: NewsCardProps) => {
  const [imageError, setImageError] = useState(false);

  const handleBookmark = () => {
    onBookmark?.(article);
  };

  const timeAgo = article.publishedAt
    ? formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true })
    : '';

  return (
    <article className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow flex flex-col h-full">
      {article.urlToImage && !imageError ? (
        <div className="relative aspect-video overflow-hidden bg-gray-200 dark:bg-gray-700">
          <img
            src={article.urlToImage}
            alt={article.title}
            className="w-full h-full object-cover"
            onError={() => setImageError(true)}
            loading="lazy"
          />
          <div className="absolute top-2 right-2 flex gap-2">
            {article.source?.name && (
              <span className="px-2 py-1 bg-black/50 text-white text-xs rounded backdrop-blur-sm">
                {article.source.name}
              </span>
            )}
          </div>
        </div>
      ) : (
        <div className="aspect-video bg-gradient-to-br from-primary-500 to-purple-600 flex items-center justify-center p-6">
          <span className="text-white text-xl font-bold text-center line-clamp-3">
            {article.title}
          </span>
        </div>
      )}

      <div className="p-4 flex-1 flex flex-col">
        <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-2 line-clamp-2">
          {article.title}
        </h3>

        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2 flex-1">
          {article.description || 'No description available.'}
        </p>

        <div className="flex items-center justify-between pt-4 border-t dark:border-gray-700">
          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <Clock className="w-3 h-3" />
            <span>{timeAgo}</span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleBookmark}
              className={`p-2 rounded-lg transition-colors ${
                isBookmarked
                  ? 'bg-primary-100 text-primary-600 dark:bg-primary-900 dark:text-primary-400'
                  : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
              }`}
              title={isBookmarked ? 'Remove bookmark' : 'Save for later'}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            <a
              href={article.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded-lg transition-colors"
              title="Read full article"
            >
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </article>
  );
};

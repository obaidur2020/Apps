import type { NewsArticle } from '../../types';
import { NewsCard } from './NewsCard';

interface NewsGridProps {
  articles: NewsArticle[];
  loading?: boolean;
  onBookmark?: (article: NewsArticle) => void;
  bookmarkedIds?: Set<string>;
}

export const NewsGrid = ({ articles, loading, onBookmark, bookmarkedIds }: NewsGridProps) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-gray-200 dark:bg-gray-700 rounded-xl h-80 animate-pulse" />
        ))}
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 dark:text-gray-400">No articles found.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles.map((article, index) => (
        <NewsCard
          key={`${article.source?.id || article.source?.name}-${index}`}
          article={article}
          onBookmark={onBookmark}
          isBookmarked={bookmarkedIds?.has(article.url)}
        />
      ))}
    </div>
  );
};

import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';

const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests (demo mode - using a fixed token)
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken') || 'demo-token';
  config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;

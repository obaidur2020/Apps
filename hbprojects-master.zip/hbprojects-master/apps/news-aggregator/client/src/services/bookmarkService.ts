import api from './api';
import type { Bookmark, SavedSearch, ApiResponse } from '../types';

interface ArticleData {
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  source: { id: string | null; name: string };
  author: string;
  publishedAt: string;
}

interface SavedSearchFilters {
  category?: string;
  source?: string;
  from?: string;
  to?: string;
}

export const bookmarkService = {
  async getBookmarks(): Promise<Bookmark[]> {
    const response = await api.get<ApiResponse<{ bookmarks: Bookmark[] }>>('/bookmarks');
    return response.data.data!.bookmarks;
  },

  async createBookmark(articleId: string, articleData: ArticleData, notes?: string): Promise<Bookmark> {
    const response = await api.post<ApiResponse<{ bookmark: Bookmark }>>('/bookmarks', {
      articleId,
      articleData,
      notes,
    });
    return response.data.data!.bookmark;
  },

  async deleteBookmark(id: string): Promise<void> {
    await api.delete(`/bookmarks/${id}`);
  },

  async updateNotes(id: string, notes: string): Promise<Bookmark> {
    const response = await api.patch<ApiResponse<{ bookmark: Bookmark }>>(`/bookmarks/${id}`, {
      notes,
    });
    return response.data.data!.bookmark;
  },
};

export const savedSearchService = {
  async getSavedSearches(): Promise<SavedSearch[]> {
    const response = await api.get<ApiResponse<{ searches: SavedSearch[] }>>('/saved-searches');
    return response.data.data!.searches;
  },

  async createSavedSearch(
    name: string,
    query: string,
    filters: SavedSearchFilters
  ): Promise<SavedSearch> {
    const response = await api.post<ApiResponse<{ search: SavedSearch }>>('/saved-searches', {
      name,
      query,
      filters,
    });
    return response.data.data!.search;
  },

  async deleteSavedSearch(id: string): Promise<void> {
    await api.delete(`/saved-searches/${id}`);
  },
};

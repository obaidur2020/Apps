import api from './api';
import type { NewsArticle, Category, NewsSource, ApiResponse } from '../types';

export const newsService = {
  async getTopHeadlines(params?: {
    country?: string;
    category?: string;
    sources?: string;
    q?: string;
    pageSize?: number;
    page?: number;
  }): Promise<{ articles: NewsArticle[]; totalResults?: number }> {
    const response = await api.get<ApiResponse<{ articles: NewsArticle[]; totalResults?: number }>>(
      '/news/headlines',
      { params }
    );
    return response.data.data!;
  },

  async getEverything(params?: {
    q?: string;
    sources?: string;
    from?: string;
    to?: string;
    language?: string;
    sortBy?: string;
    pageSize?: number;
    page?: number;
  }): Promise<{ articles: NewsArticle[]; totalResults?: number }> {
    const response = await api.get<ApiResponse<{ articles: NewsArticle[]; totalResults?: number }>>(
      '/news/everything',
      { params }
    );
    return response.data.data!;
  },

  async getSources(params?: {
    category?: string;
    language?: string;
    country?: string;
  }): Promise<{ sources: NewsSource[] }> {
    const response = await api.get<ApiResponse<{ sources: NewsSource[] }>>('/news/sources', {
      params,
    });
    return response.data.data!;
  },

  async getCategories(): Promise<{ categories: Category[] }> {
    const response = await api.get<ApiResponse<{ categories: Category[] }>>('/news/categories');
    return response.data.data!;
  },
};

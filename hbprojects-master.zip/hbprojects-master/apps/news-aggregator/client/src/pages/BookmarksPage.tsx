import { useState, useEffect } from 'react';
import { bookmarkService } from '../services/bookmarkService';
import { Header } from '../components/common/Header';
import { Bookmark as BookmarkIcon, Trash2 } from 'lucide-react';
import type { Bookmark } from '../types';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

export const BookmarksPage = () => {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBookmarks();
  }, []);

  const loadBookmarks = async () => {
    try {
      const data = await bookmarkService.getBookmarks();
      setBookmarks(data);
    } catch (error) {
      toast.error('Failed to load bookmarks');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await bookmarkService.deleteBookmark(id);
      setBookmarks((prev) => prev.filter((b) => b._id !== id));
      toast.success('Bookmark removed');
    } catch (error) {
      toast.error('Failed to remove bookmark');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center gap-3 mb-6">
          <BookmarkIcon className="w-6 h-6 text-primary-600" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Saved Articles</h1>
          <span className="text-gray-500 dark:text-gray-400">({bookmarks.length})</span>
        </div>

        {bookmarks.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl">
            <BookmarkIcon className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500 dark:text-gray-400">No saved articles yet.</p>
            <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
              Bookmark articles to read them later.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {bookmarks.map((bookmark) => (
              <div
                key={bookmark._id}
                className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow hover:shadow-md transition-shadow"
              >
                <div className="flex gap-4">
                  {bookmark.articleData.urlToImage && (
                    <img
                      src={bookmark.articleData.urlToImage}
                      alt={bookmark.articleData.title}
                      className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
                    />
                  )}

                  <div className="flex-1 min-w-0">
                    <a
                      href={bookmark.articleData.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-semibold text-gray-900 dark:text-white hover:text-primary-600 dark:hover:text-primary-400 line-clamp-2"
                    >
                      {bookmark.articleData.title}
                    </a>

                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">
                      {bookmark.articleData.description}
                    </p>

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        Saved {formatDistanceToNow(new Date(bookmark.createdAt), { addSuffix: true })}
                      </span>

                      <button
                        onClick={() => handleDelete(bookmark._id)}
                        className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

import { useState, useEffect } from 'react';
import { newsService } from '../services/newsService';
import { CategoryNav } from '../components/news/CategoryNav';
import { NewsGrid } from '../components/news/NewsGrid';
import { SearchBar } from '../components/common/SearchBar';
import { Header } from '../components/common/Header';
import { Loader2 } from 'lucide-react';
import type { Category, NewsArticle } from '../types';
import toast from 'react-hot-toast';
import { bookmarkService } from '../services/bookmarkService';

interface ApiError {
  response?: {
    data?: {
      error?: { message: string };
    };
  };
}

export const HomePage = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('general');
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkedUrls, setBookmarkedUrls] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadCategories();
    loadBookmarks();
  }, []);

  useEffect(() => {
    loadNews();
  }, [activeCategory, searchQuery]);

  const loadCategories = async () => {
    try {
      const { categories: cats } = await newsService.getCategories();
      setCategories(cats);
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  const loadBookmarks = async () => {
    try {
      const bookmarks = await bookmarkService.getBookmarks();
      const urls = new Set(bookmarks.map((b) => b.articleData.url));
      setBookmarkedUrls(urls);
    } catch (error) {
      // Ignore error for demo
    }
  };

  const loadNews = async () => {
    setLoading(true);
    try {
      const { articles: news } = searchQuery
        ? await newsService.getEverything({ q: searchQuery, pageSize: 21 })
        : await newsService.getTopHeadlines({ category: activeCategory, pageSize: 21 });

      setArticles(news);
    } catch (error) {
      const err = error as ApiError;
      const message = err.response?.data?.error?.message || 'Failed to load news';
      toast.error(message);
      setArticles([]);
    } finally {
      setLoading(false);
    }
  };

  const handleBookmark = async (article: NewsArticle) => {
    if (bookmarkedUrls.has(article.url)) {
      toast.success('Removed from bookmarks');
      setBookmarkedUrls((prev) => {
        const next = new Set(prev);
        next.delete(article.url);
        return next;
      });
    } else {
      try {
        await bookmarkService.createBookmark(article.url, article);
        toast.success('Saved to bookmarks');
        setBookmarkedUrls((prev) => new Set(prev).add(article.url));
      } catch (error) {
        toast.error('Failed to save bookmark');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Bar */}
        <div className="mb-6">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            onSearch={loadNews}
            placeholder="Search for news..."
          />
        </div>

        {/* Categories */}
        {!searchQuery && (
          <div className="mb-6">
            <CategoryNav
              categories={categories}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
            />
          </div>
        )}

        {/* Results Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {searchQuery ? `Results for "${searchQuery}"` : 'Top Headlines'}
          </h2>
          {loading && <Loader2 className="w-5 h-5 animate-spin text-primary-600" />}
        </div>

        {/* News Grid */}
        <NewsGrid
          articles={articles}
          loading={loading}
          onBookmark={handleBookmark}
          bookmarkedIds={bookmarkedUrls}
        />
      </main>
    </div>
  );
};

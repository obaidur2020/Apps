import { Router } from 'express';
import User from '../models/User';
import { auth, AuthRequest } from '../middleware/auth';

const router = Router();

router.use(auth);

router.get('/me', async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ success: false, error: { message: 'Unauthorized' } });

  const user = await User.findOne({ email: req.user.email });
  if (!user) {
    // Create demo user
    const newUser = await User.create({
      email: req.user.email,
      name: 'Demo User',
      preferences: {
        categories: [],
        sources: [],
        country: 'us',
        language: 'en',
        theme: 'auto',
      },
    });
    return res.json({ success: true, data: { user: newUser } });
  }

  res.json({ success: true, data: { user } });
});

router.put('/me', async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ success: false, error: { message: 'Unauthorized' } });

  const user = await User.findOneAndUpdate(
    { email: req.user.email },
    { $set: req.body },
    { new: true, runValidators: true }
  );

  res.json({ success: true, data: { user } });
});

export default router;

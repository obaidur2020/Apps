import { Router } from 'express';
import {
  getTopHeadlines,
  getEverything,
  getSources,
  getCategories,
} from '../controllers/newsController';

const router = Router();

router.get('/headlines', getTopHeadlines);
router.get('/everything', getEverything);
router.get('/sources', getSources);
router.get('/categories', getCategories);

export default router;

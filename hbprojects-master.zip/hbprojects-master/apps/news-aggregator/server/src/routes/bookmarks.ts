import { Router } from 'express';
import {
  getBookmarks,
  createBookmark,
  deleteBookmark,
  updateBookmarkNotes,
} from '../controllers/bookmarkController';
import { auth } from '../middleware/auth';

const router = Router();

router.use(auth);

router.route('/').get(getBookmarks).post(createBookmark);
router.route('/:id').delete(deleteBookmark).patch(updateBookmarkNotes);

export default router;

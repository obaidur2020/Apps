import { Router } from 'express';
import SavedSearch from '../models/SavedSearch';
import { auth, AuthRequest } from '../middleware/auth';

const router = Router();

router.use(auth);

router.get('/', async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ success: false, error: { message: 'Unauthorized' } });

  const searches = await SavedSearch.find({ userId: req.user.userId }).sort({ createdAt: -1 });
  res.json({ success: true, data: { searches } });
});

router.post('/', async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ success: false, error: { message: 'Unauthorized' } });

  const { name, query, filters } = req.body;
  const search = await SavedSearch.create({ userId: req.user.userId, name, query, filters });
  res.status(201).json({ success: true, data: { search } });
});

router.delete('/:id', async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ success: false, error: { message: 'Unauthorized' } });

  const search = await SavedSearch.findOneAndDelete({
    _id: req.params.id,
    userId: req.user.userId,
  });

  if (!search) {
    return res.status(404).json({ success: false, error: { message: 'Saved search not found' } });
  }

  res.json({ success: true, data: { message: 'Deleted' } });
});

export default router;

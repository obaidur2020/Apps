import axios from 'axios';

const NEWS_API_KEY = process.env.NEWS_API_KEY || '';
const NEWS_API_URL = 'https://newsapi.org/v2';

interface NewsArticle {
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  source: { id: string | null; name: string };
  author: string;
  publishedAt: string;
  content: string;
}

interface NewsAPIResponse {
  status: string;
  articles: NewsArticle[];
  totalResults?: number;
  sources?: Array<{ id: string; name: string; category: string; country: string }>;
}

export class NewsAPIClient {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private async request(endpoint: string, params: Record<string, string | number> = {}): Promise<NewsAPIResponse> {
    try {
      const response = await axios.get(`${NEWS_API_URL}${endpoint}`, {
        params: {
          apiKey: this.apiKey,
          ...params,
        },
      });
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        throw new Error(error.response?.data?.message || 'Failed to fetch from NewsAPI');
      }
      throw error;
    }
  }

  async getTopHeadlines(params: {
    country?: string;
    category?: string;
    sources?: string;
    q?: string;
    pageSize?: number;
    page?: number;
  } = {}) {
    return this.request('/top-headlines', params);
  }

  async getEverything(params: {
    q?: string;
    sources?: string;
    domains?: string;
    from?: string;
    to?: string;
    language?: string;
    sortBy?: string;
    pageSize?: number;
    page?: number;
  } = {}) {
    return this.request('/everything', params);
  }

  async getSources(params: {
    category?: string;
    language?: string;
    country?: string;
  } = {}) {
    return this.request('/sources', params);
  }
}

// Export singleton instance
export const newsApiClient = new NewsAPIClient(NEWS_API_KEY);

export const isConfigured = (): boolean => {
  return !!NEWS_API_KEY && NEWS_API_KEY !== 'your_news_api_key_here';
};

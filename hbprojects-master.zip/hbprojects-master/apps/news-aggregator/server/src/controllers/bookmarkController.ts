import { Response } from 'express';
import Bookmark from '../models/Bookmark';
import { AuthRequest } from '../middleware/auth';

interface MongoError {
  code: number;
  message: string;
}

export const getBookmarks = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const bookmarks = await Bookmark.find({ userId: req.user.userId })
      .sort({ createdAt: -1 })
      .lean();

    res.status(200).json({ success: true, data: { bookmarks } });
  } catch (error) {
    console.error('Get bookmarks error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

export const createBookmark = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { articleId, articleData, notes } = req.body;

    const bookmark = await Bookmark.create({
      userId: req.user.userId,
      articleId,
      articleData,
      notes,
    });

    res.status(201).json({ success: true, data: { bookmark } });
  } catch (error) {
    const err = error as MongoError;
    if (err.code === 11000) {
      res.status(400).json({ success: false, error: { message: 'Article already bookmarked' } });
      return;
    }
    console.error('Create bookmark error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

export const deleteBookmark = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const bookmark = await Bookmark.findOneAndDelete({
      _id: req.params.id,
      userId: req.user.userId,
    });

    if (!bookmark) {
      res.status(404).json({ success: false, error: { message: 'Bookmark not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { message: 'Bookmark removed' } });
  } catch (error) {
    console.error('Delete bookmark error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

export const updateBookmarkNotes = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: { message: 'Not authenticated' } });
      return;
    }

    const { notes } = req.body;

    const bookmark = await Bookmark.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      { notes },
      { new: true }
    );

    if (!bookmark) {
      res.status(404).json({ success: false, error: { message: 'Bookmark not found' } });
      return;
    }

    res.status(200).json({ success: true, data: { bookmark } });
  } catch (error) {
    console.error('Update bookmark error:', error);
    res.status(500).json({ success: false, error: { message: 'Server error' } });
  }
};

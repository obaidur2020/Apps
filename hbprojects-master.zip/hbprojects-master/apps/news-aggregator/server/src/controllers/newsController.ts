import { Request, Response } from 'express';
import { newsApiClient, isConfigured } from '../services/newsApi';

interface NewsApiError {
  message: string;
  response?: { data?: { message?: string } };
}

export const getTopHeadlines = async (req: Request, res: Response): Promise<void> => {
  try {
    const { country, category = 'general', sources, q, pageSize = 20, page = 1 } = req.query;

    // Demo mode - return mock data
    if (!isConfigured()) {
      const demoArticles = [
        {
          title: `Demo: Latest ${category} News Headline`,
          description: 'This is demo news. Add NEWS_API_KEY to .env for real news.',
          url: 'https://demo.news/article1',
          urlToImage: '',
          publishedAt: new Date().toISOString(),
          source: { id: 'demo', name: 'Demo Source' },
          author: 'Demo Author',
          content: 'Demo content for testing...',
        },
        {
          title: `Demo: Another ${category} Story`,
          description: 'More demo news content for testing the UI.',
          url: 'https://demo.news/article2',
          urlToImage: '',
          publishedAt: new Date(Date.now() - 3600000).toISOString(),
          source: { id: 'demo', name: 'Demo News' },
          author: 'Demo Writer',
          content: 'Additional demo content...',
        },
        {
          title: `Demo: Breaking ${category} Update`,
          description: 'This is a breaking news demo item.',
          url: 'https://demo.news/article3',
          urlToImage: '',
          publishedAt: new Date(Date.now() - 7200000).toISOString(),
          source: { id: 'demo', name: 'Demo Breaking' },
          author: 'Demo Reporter',
          content: 'Breaking demo content...',
        },
      ];
      res.status(200).json({
        success: true,
        data: { articles: demoArticles, totalResults: 3 },
      });
      return;
    }

    const response = await newsApiClient.getTopHeadlines({
      country: country as string,
      category: category as string,
      sources: sources as string,
      q: q as string,
      pageSize: Number(pageSize),
      page: Number(page),
    });

    res.status(200).json({
      success: true,
      data: {
        articles: response.articles,
        totalResults: response.totalResults,
      },
    });
  } catch (error) {
    const err = error as NewsApiError;
    console.error('NewsAPI error:', err.message);
    res.status(500).json({
      success: false,
      error: { message: err.message || 'Failed to fetch headlines' },
    });
  }
};

export const getEverything = async (req: Request, res: Response): Promise<void> => {
  try {
    const { q = 'news', sources, domains, from, to, language, sortBy = 'publishedAt', pageSize = 20, page = 1 } = req.query;

    // Demo mode - return mock data
    if (!isConfigured()) {
      const demoArticles = [
        {
          title: `Demo: Search results for "${q}"`,
          description: 'This is demo search news. Add NEWS_API_KEY to .env for real results.',
          url: 'https://demo.news/search1',
          urlToImage: '',
          publishedAt: new Date().toISOString(),
          source: { id: 'demo', name: 'Demo Search' },
          author: 'Demo Author',
          content: 'Demo search content...',
        },
        {
          title: `Demo: More results for "${q}"`,
          description: 'Additional search demo content.',
          url: 'https://demo.news/search2',
          urlToImage: '',
          publishedAt: new Date(Date.now() - 3600000).toISOString(),
          source: { id: 'demo', name: 'Demo Results' },
          author: 'Demo Writer',
          content: 'More demo content...',
        },
      ];
      res.status(200).json({
        success: true,
        data: { articles: demoArticles, totalResults: 2 },
      });
      return;
    }

    const response = await newsApiClient.getEverything({
      q: q as string,
      sources: sources as string,
      domains: domains as string,
      from: from as string,
      to: to as string,
      language: language as string,
      sortBy: sortBy as string,
      pageSize: Number(pageSize),
      page: Number(page),
    });

    res.status(200).json({
      success: true,
      data: {
        articles: response.articles,
        totalResults: response.totalResults,
      },
    });
  } catch (error) {
    const err = error as NewsApiError;
    console.error('NewsAPI error:', err.message);
    res.status(500).json({
      success: false,
      error: { message: err.message || 'Failed to search articles' },
    });
  }
};

export const getSources = async (req: Request, res: Response): Promise<void> => {
  try {
    // Demo mode - return mock sources
    if (!isConfigured()) {
      const demoSources = [
        { id: 'demo-news', name: 'Demo News', category: 'general', language: 'en', country: 'us' },
        { id: 'demo-tech', name: 'Demo Tech', category: 'technology', language: 'en', country: 'us' },
        { id: 'demo-sports', name: 'Demo Sports', category: 'sports', language: 'en', country: 'us' },
      ];
      res.status(200).json({
        success: true,
        data: { sources: demoSources },
      });
      return;
    }

    const { category, language, country } = req.query;

    const response = await newsApiClient.getSources({
      category: category as string,
      language: language as string,
      country: country as string,
    });

    res.status(200).json({
      success: true,
      data: { sources: response.sources },
    });
  } catch (error) {
    const err = error as NewsApiError;
    console.error('NewsAPI error:', err.message);
    res.status(500).json({
      success: false,
      error: { message: err.message || 'Failed to fetch sources' },
    });
  }
};

// Categories available in NewsAPI
export const getCategories = async (req: Request, res: Response): Promise<void> => {
  const categories = [
    { id: 'business', name: 'Business', icon: '💼' },
    { id: 'entertainment', name: 'Entertainment', icon: '🎬' },
    { id: 'general', name: 'General', icon: '📰' },
    { id: 'health', name: 'Health', icon: '🏥' },
    { id: 'science', name: 'Science', icon: '🔬' },
    { id: 'sports', name: 'Sports', icon: '⚽' },
    { id: 'technology', name: 'Technology', icon: '💻' },
  ];

  res.status(200).json({ success: true, data: { categories } });
};

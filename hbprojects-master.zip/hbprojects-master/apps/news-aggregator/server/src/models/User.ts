import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IUserPreferences {
  categories: string[];
  sources: string[];
  country: string;
  language: string;
  theme: 'light' | 'dark' | 'auto';
}

export interface IUser extends Document {
  email: string;
  name: string;
  avatar?: string;
  preferences: IUserPreferences;
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>(
  {
    email: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    avatar: String,
    preferences: {
      categories: { type: [String], default: [] },
      sources: { type: [String], default: [] },
      country: { type: String, default: 'us' },
      language: { type: String, default: 'en' },
      theme: { type: String, enum: ['light', 'dark', 'auto'], default: 'auto' },
    },
  },
  { timestamps: true }
);

export default mongoose.model<IUser>('User', UserSchema);

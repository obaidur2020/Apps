import mongoose, { Document, Schema } from 'mongoose';

export interface ISavedSearch extends Document {
  userId: mongoose.Types.ObjectId;
  name: string;
  query: string;
  filters: {
    category?: string;
    source?: string;
    from?: string;
    to?: string;
    language?: string;
    sortBy?: string;
  };
  createdAt: Date;
}

const SavedSearchSchema = new Schema<ISavedSearch>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: true },
    query: String,
    filters: {
      category: String,
      source: String,
      from: String,
      to: String,
      language: String,
      sortBy: String,
    },
  },
  { timestamps: true }
);

export default mongoose.model<ISavedSearch>('SavedSearch', SavedSearchSchema);

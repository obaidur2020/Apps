import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IBookmark extends Document {
  userId: Types.ObjectId;
  articleId: string;
  articleData: {
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    source: { id: string | null; name: string };
    author: string;
    publishedAt: string;
    category?: string;
  };
  notes?: string;
  createdAt: Date;
}

const BookmarkSchema = new Schema<IBookmark>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    articleId: { type: String, required: true },
    articleData: {
      title: String,
      description: String,
      url: String,
      urlToImage: String,
      source: {
        id: String,
        name: String,
      },
      author: String,
      publishedAt: String,
      category: String,
    },
    notes: String,
  },
  { timestamps: true }
);

// Compound index to prevent duplicate bookmarks
BookmarkSchema.index({ userId: 1, articleId: 1 }, { unique: true });

export default mongoose.model<IBookmark>('Bookmark', BookmarkSchema);

import { Request, Response, NextFunction } from 'express';

export interface AuthRequest extends Request {
  user?: { userId: string; email: string };
}

// Demo user ID - valid 24-character hex string (MongoDB ObjectId format)
const DEMO_USER_ID = '000000000000000000000001';

// Simple auth middleware - for demo purposes, using a mock user
// In production, this would verify JWT tokens
export const auth = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({
        success: false,
        error: { message: 'No token provided' },
      });
      return;
    }

    // For demo: decode mock user from token
    // In production, verify JWT properly
    const token = authHeader.substring(7);

    // Simple demo: accept any non-empty token
    if (token) {
      req.user = { userId: DEMO_USER_ID, email: 'demo@example.com' };
      next();
    } else {
      res.status(401).json({ success: false, error: { message: 'Invalid token' } });
    }
  } catch (error) {
    res.status(401).json({ success: false, error: { message: 'Invalid token' } });
  }
};

import express, { Application, Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import connectDB from './config/db';

// Load environment variables
dotenv.config();

// Import routes
import newsRoutes from './routes/news';
import bookmarkRoutes from './routes/bookmarks';
import savedSearchRoutes from './routes/savedSearches';
import userRoutes from './routes/users';

// Connect to MongoDB
connectDB();

// Initialize Express app
const app: Application = express();
const PORT = process.env.PORT || 5001;

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests from this IP, please try again later.',
});

// Middleware
app.use(limiter);
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5177',
  credentials: true,
}));
app.use(express.json());

// Health check route
app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({ status: 'OK', message: 'News Aggregator Server is running' });
});

// API routes
app.use('/api/news', newsRoutes);
app.use('/api/bookmarks', bookmarkRoutes);
app.use('/api/saved-searches', savedSearchRoutes);
app.use('/api/users', userRoutes);

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({ success: false, error: { message: 'Route not found' } });
});

// Start server
app.listen(PORT, () => {
  console.log(`News Aggregator Server running on port ${PORT}`);
});

export default app;

export interface Playlist {
  _id: string;
  name: string;
  description: string;
  isPublic: boolean;
  songs: Song[];
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Song {
  _id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  url: string;
}

import axios from 'axios';

const api = axios.create({ baseURL: 'http://localhost:5007/api' });

api.interceptors.request.use((c) => {
  c.headers.Authorization = `Bearer ${localStorage.getItem('token') || 'demo'}`;
  return c;
});

export const playlistService = {
  async getPlaylists() {
    return (await api.get('/playlists')).data.data;
  },
  async createPlaylist(data: { name: string; description: string; isPublic: boolean }) {
    return (await api.post('/playlists', data)).data.data;
  },
  async deletePlaylist(id: string) {
    return (await api.delete(`/playlists/${id}`)).data.data;
  },
  async addSong(playlistId: string, song: any) {
    return (await api.post(`/playlists/${playlistId}/songs`, song)).data.data;
  },
};

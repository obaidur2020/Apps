import { useState, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Plus, Trash2, Heart, Search, Music, ListPlus } from 'lucide-react';
import { playlistService } from './services/api';
import type { Playlist, Song } from './types';
import { toast } from 'react-hot-toast';

export default function App() {
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [songs, setSongs] = useState<Song[]>([]);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [newPlaylist, setNewPlaylist] = useState({ name: '', description: '', isPublic: true });

  useEffect(() => {
    loadPlaylists();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && currentSong) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 0.5;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentSong]);

  const loadPlaylists = async () => {
    const data = await playlistService.getPlaylists();
    setPlaylists(data.playlists);
    if (data.playlists.length > 0 && data.playlists[0].songs.length > 0) {
      setSongs(data.playlists[0].songs);
    }
  };

  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    await playlistService.createPlaylist(newPlaylist);
    setModalOpen(false);
    setNewPlaylist({ name: '', description: '', isPublic: true });
    loadPlaylists();
    toast.success('Playlist created!');
  };

  const handleAddSong = async (playlistId: string) => {
    // Demo songs - in a real app this would come from a file picker or API
    const demoSong: Song = {
      _id: Date.now().toString(),
      title: `Song ${Math.floor(Math.random() * 1000)}`,
      artist: 'Demo Artist',
      album: 'Demo Album',
      duration: 180,
      url: '',
    };
    await playlistService.addSong(playlistId, demoSong);
    loadPlaylists();
    toast.success('Song added!');
  };

  const handleDeletePlaylist = async (id: string) => {
    await playlistService.deletePlaylist(id);
    loadPlaylists();
    toast.success('Playlist deleted!');
  };

  const playSong = (song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    setProgress(0);
  };

  const playNext = () => {
    if (songs.length === 0) return;
    const currentIndex = songs.findIndex(s => s._id === currentSong?._id);
    const nextIndex = (currentIndex + 1) % songs.length;
    playSong(songs[nextIndex]);
  };

  const playPrevious = () => {
    if (songs.length === 0) return;
    const currentIndex = songs.findIndex(s => s._id === currentSong?._id);
    const prevIndex = currentIndex === 0 ? songs.length - 1 : currentIndex - 1;
    playSong(songs[prevIndex]);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredPlaylists = playlists.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950">
      {/* Animated background */}
      <div className="fixed inset-0 opacity-30">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))]"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-900/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-5">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 rounded-xl blur-lg opacity-50 animate-pulse"></div>
                <div className="relative w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center shadow-lg shadow-pink-500/30">
                  <Music className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Music Playlist</h1>
                <p className="text-sm text-slate-400">{playlists.length} playlists</p>
              </div>
            </div>
            <button
              onClick={() => setModalOpen(true)}
              className="group relative px-6 py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-medium rounded-xl overflow-hidden transition-all hover:scale-105 hover:shadow-xl hover:shadow-pink-500/30"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform"></div>
              <span className="relative flex items-center gap-2">
                <Plus className="w-5 h-5" /> New Playlist
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search playlists..."
              className="w-full pl-12 pr-4 py-4 bg-slate-800/50 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all"
            />
          </div>
        </div>

        {/* Playlists Grid */}
        {filteredPlaylists.length === 0 ? (
          <div className="text-center py-24">
            <div className="relative w-24 h-24 mx-auto mb-8">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 rounded-3xl blur-2xl opacity-30"></div>
              <div className="relative bg-slate-800 rounded-3xl flex items-center justify-center">
                <Music className="w-10 h-10 text-pink-400" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">No playlists yet</h3>
            <p className="text-slate-400 mb-8">Create your first playlist and add your favorite songs</p>
            <button
              onClick={() => setModalOpen(true)}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-medium rounded-2xl hover:scale-105 transition-all shadow-xl shadow-pink-500/30"
            >
              <Plus className="w-5 h-5" /> Create Playlist
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPlaylists.map((playlist) => (
              <div
                key={playlist._id}
                className="group relative bg-slate-900/50 border border-slate-800 hover:border-pink-500/50 rounded-3xl overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-pink-500/10 hover:-translate-y-1"
              >
                {/* Cover Image */}
                <div className="relative h-48 bg-gradient-to-br from-pink-500/20 to-purple-600/20 flex items-center justify-center">
                  <Music className="w-16 h-16 text-pink-400 opacity-50" />
                  <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-slate-900 to-transparent"></div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-lg font-bold text-white mb-2">{playlist.name}</h3>
                  <p className="text-sm text-slate-400 mb-4">{playlist.description || 'No description'}</p>
                  <div className="flex items-center justify-between text-sm text-slate-400 mb-4">
                    <span>{playlist.songs.length} songs</span>
                    {playlist.isPublic && (
                      <span className="px-2 py-1 bg-green-500/10 text-green-400 text-xs rounded-full">Public</span>
                    )}
                  </div>

                  {/* Songs Preview */}
                  {playlist.songs.length > 0 && (
                    <div className="space-y-2 mb-4">
                      {playlist.songs.slice(0, 3).map((song) => (
                        <div
                          key={song._id}
                          onClick={() => playSong(song)}
                          className={`p-3 rounded-xl cursor-pointer transition-all ${
                            currentSong?._id === song._id
                              ? 'bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/50'
                              : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                                {currentSong?._id === song._id && isPlaying ? (
                                  <Pause className="w-5 h-5 text-white" />
                                ) : (
                                  <Play className="w-5 h-5 text-white" />
                                )}
                              </div>
                              <div>
                                <p className="text-sm font-medium text-white">{song.title}</p>
                                <p className="text-xs text-slate-400">{song.artist}</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500">{formatTime(song.duration)}</span>
                          </div>
                        </div>
                      ))}
                      {playlist.songs.length > 3 && (
                        <p className="text-xs text-slate-500 text-center">+{playlist.songs.length - 3} more songs</p>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleAddSong(playlist._id)}
                      className="flex-1 py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-xl font-medium hover:opacity-90 transition-all flex items-center justify-center gap-2"
                    >
                      <ListPlus className="w-4 h-4" /> Add Song
                    </button>
                    <button
                      onClick={() => handleDeletePlaylist(playlist._id)}
                      className="p-3 bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 rounded-xl transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Player Bar */}
      {currentSong && (
        <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-white/10 bg-slate-900/95 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between gap-6">
              {/* Song Info */}
              <div className="flex items-center gap-4 flex-1 min-w-0">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                  <Music className="w-7 h-7 text-white" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-white font-medium truncate">{currentSong.title}</h4>
                  <p className="text-sm text-slate-400 truncate">{currentSong.artist}</p>
                </div>
                <button className="p-2 text-pink-400 hover:text-pink-300">
                  <Heart className="w-5 h-5" />
                </button>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-4">
                <button className="p-2 text-slate-400 hover:text-white transition-colors">
                  <Shuffle className="w-5 h-5" />
                </button>
                <button onClick={playPrevious} className="p-2 text-slate-400 hover:text-white transition-colors">
                  <SkipBack className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-14 h-14 rounded-full bg-white text-slate-900 flex items-center justify-center hover:scale-105 transition-transform"
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                </button>
                <button onClick={playNext} className="p-2 text-slate-400 hover:text-white transition-colors">
                  <SkipForward className="w-5 h-5" />
                </button>
                <button className="p-2 text-slate-400 hover:text-white transition-colors">
                  <Repeat className="w-5 h-5" />
                </button>
              </div>

              {/* Progress */}
              <div className="hidden lg:flex items-center gap-4 flex-1">
                <span className="text-xs text-slate-400">{formatTime(progress * (currentSong.duration / 100))}</span>
                <div className="flex-1 h-1 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-500 to-purple-600 rounded-full transition-all"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <span className="text-xs text-slate-400">{formatTime(currentSong.duration)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Playlist Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModalOpen(false)}></div>
          <div className="relative bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl shadow-pink-500/20 w-full max-w-lg p-8">
            <form onSubmit={handleCreatePlaylist} className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center">
                    <Plus className="w-6 h-6 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-white">Create Playlist</h2>
                </div>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-all"
                >
                  ✕
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-3">Playlist Name</label>
                <input
                  value={newPlaylist.name}
                  onChange={(e) => setNewPlaylist({ ...newPlaylist, name: e.target.value })}
                  placeholder="My Awesome Playlist"
                  className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-3">Description</label>
                <textarea
                  value={newPlaylist.description}
                  onChange={(e) => setNewPlaylist({ ...newPlaylist, description: e.target.value })}
                  placeholder="What's this playlist about?"
                  className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all resize-none"
                  rows={3}
                />
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  className="flex-1 py-4 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-medium rounded-2xl hover:scale-[1.02] transition-all shadow-xl shadow-pink-500/30"
                >
                  Create Playlist
                </button>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-8 py-4 bg-slate-800 text-slate-300 font-medium rounded-2xl hover:bg-slate-700 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

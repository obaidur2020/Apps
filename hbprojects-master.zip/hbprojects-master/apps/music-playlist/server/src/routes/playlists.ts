import express from 'express';
import Playlist from '../models/Playlist';

const router = express.Router();

// Demo user ID - valid 24-character hex string (MongoDB ObjectId format)
const DEMO_USER_ID = '000000000000000000000001';

router.get('/', async (req, res) => {
  const playlists = await Playlist.find({ isPublic: true }).sort({ createdAt: -1 });
  res.json({ success: true, data: { playlists } });
});

router.post('/', async (req, res) => {
  const playlist = await Playlist.create({ ...req.body, userId: DEMO_USER_ID });
  res.status(201).json({ success: true, data: { playlist } });
});

router.post('/:id/songs', async (req, res) => {
  const playlist = await Playlist.findById(req.params.id);
  if (!playlist) return res.status(404).json({ success: false, error: { message: 'Not found' } });
  playlist.songs.push(req.body);
  await playlist.save();
  res.json({ success: true, data: { playlist } });
});

router.delete('/:id/songs/:songId', async (req, res) => {
  const playlist = await Playlist.findByIdAndUpdate(
    req.params.id,
    { $pull: { songs: { _id: req.params.songId } } },
    { new: true }
  );
  if (!playlist) return res.status(404).json({ success: false, error: { message: 'Not found' } });
  res.json({ success: true, data: { playlist } });
});

export default router;

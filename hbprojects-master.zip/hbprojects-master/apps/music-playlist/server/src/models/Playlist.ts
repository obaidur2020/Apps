import mongoose from 'mongoose';

const SongSchema = new mongoose.Schema({
  source: { type: String, enum: ['spotify', 'youtube'] },
  sourceId: String,
  title: String,
  artist: String,
  album: String,
  duration: Number,
  artwork: String,
}, { _id: false });

const PlaylistSchema = new mongoose.Schema({
  userId: String,
  name: String,
  description: String,
  coverImage: String,
  isPublic: { type: Boolean, default: false },
  songs: [SongSchema],
  followers: [String],
  playCount: { type: Number, default: 0 },
}, { timestamps: true });

export default mongoose.model('Playlist', PlaylistSchema);

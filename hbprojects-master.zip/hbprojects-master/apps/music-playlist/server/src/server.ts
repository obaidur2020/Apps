import express, { Request, Response } from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import playlistRoutes from './routes/playlists';

dotenv.config();
const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/music-playlist';
const port = process.env.PORT || 5007;
const clientOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5176';

mongoose.connect(mongoUri);

const app = express();
app.use(cors({ origin: clientOrigin }));
app.use(express.json());

app.get('/health', (_req: Request, res: Response) => res.json({ status: 'OK' }));
app.use('/api/playlists', playlistRoutes);

app.listen(port, () => console.log(`Music Server on ${port}`));

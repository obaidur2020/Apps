# Music Playlist

A full-stack music playlist application with playlist management and music player controls.

## 🚀 Quick Start

```bash
docker-compose up -d
```

## 🌐 Access

- **Frontend**: http://localhost:5176
- **Backend API**: http://localhost:5007
- **Health Check**: http://localhost:5007/health

## ✨ Features

- Create, edit, and delete playlists
- Add songs to playlists
- Music player with play/pause controls
- Skip forward/backward
- Progress bar
- Shuffle and repeat modes
- Search playlists
- Dark mode support
- Modern gradient UI

## 🔧 Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript, MongoDB
- **Database**: MongoDB

## 📁 Structure

```
music-playlist/
├── client/          # React frontend
│   └── src/
│       ├── components/
│       ├── pages/
│       ├── services/
│       └── types/
└── server/          # Express backend
    └── src/
        ├── models/
        ├── routes/
        └── controllers/
```

## 🐳 Docker Services

- `music-playlist-server` - Backend API (port 5007)
- `music-playlist-client` - Frontend UI (port 5176)

## 📝 API Endpoints

- `GET /api/playlists` - Get all playlists
- `POST /api/playlists` - Create playlist
- `GET /api/playlists/:id` - Get playlist by ID
- `PUT /api/playlists/:id` - Update playlist
- `DELETE /api/playlists/:id` - Delete playlist
- `POST /api/playlists/:id/songs` - Add song to playlist

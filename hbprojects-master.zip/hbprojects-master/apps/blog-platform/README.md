# Blog Platform

A full-stack blog platform with article management, markdown support, comments, and tags.

## 🚀 Quick Start

```bash
docker-compose up -d
```

## 🌐 Access

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5005
- **Health Check**: http://localhost:5005/health

## ✨ Features

- Create, edit, and delete articles
- Markdown support for content
- Tags and categories
- Comment system
- Like articles
- Author profiles
- Dark mode support
- Responsive design

## 🔧 Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript, MongoDB
- **Database**: MongoDB

## 📁 Structure

```
blog-platform/
├── client/          # React frontend
│   └── src/
│       ├── components/
│       ├── pages/
│       └── services/
└── server/          # Express backend
    └── src/
        ├── models/
        ├── routes/
        └── controllers/
```

## 🐳 Docker Services

- `blog-platform-server` - Backend API (port 5005)
- `blog-platform-client` - Frontend UI (port 5173)

## 📝 API Endpoints

- `GET /api/articles` - Get all articles
- `POST /api/articles` - Create article
- `GET /api/articles/:id` - Get article by ID
- `PUT /api/articles/:id` - Update article
- `DELETE /api/articles/:id` - Delete article
- `POST /api/articles/:id/comments` - Add comment
- `POST /api/articles/:id/like` - Like article

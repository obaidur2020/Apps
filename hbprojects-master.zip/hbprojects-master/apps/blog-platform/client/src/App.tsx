import { useState, useEffect } from 'react';
import { PenTool, Calendar, User, Heart, X } from 'lucide-react';
import axios from 'axios';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import toast, { Toaster } from 'react-hot-toast';

const API_URL = 'http://localhost:5005/api';

interface Article {
  _id: string;
  title: string;
  content: string;
  excerpt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  stats: { likes: number };
}

function App() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [selected, setSelected] = useState<Article | null>(null);
  const [showWrite, setShowWrite] = useState(false);
  const [newArticle, setNewArticle] = useState({ title: '', content: '', tags: '' });

  useEffect(() => {
    axios.get(`${API_URL}/articles`).then(res => setArticles(res.data.data.articles));
  }, []);

  const handleWrite = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const tags = newArticle.tags.split(',').map(t => t.trim()).filter(Boolean);
      await axios.post(`${API_URL}/articles`, {
        title: newArticle.title,
        content: newArticle.content,
        tags
      });
      toast.success('Article published!');
      setNewArticle({ title: '', content: '', tags: '' });
      setShowWrite(false);
      // Refresh articles
      axios.get(`${API_URL}/articles`).then(res => setArticles(res.data.data.articles));
    } catch (err: any) {
      toast.error(err.response?.data?.error?.message || 'Failed to publish');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Toaster />
      <header className="bg-white dark:bg-gray-800 shadow p-4">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold flex items-center gap-2 dark:text-white">
            <PenTool className="w-6 h-6 text-blue-600" /> Blog
          </h1>
          <button
            onClick={() => setShowWrite(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Write
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4">
        {showWrite ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold dark:text-white">Write Article</h2>
              <button onClick={() => setShowWrite(false)} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleWrite} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 dark:text-white">Title</label>
                <input
                  type="text"
                  value={newArticle.title}
                  onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  placeholder="Enter article title..."
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 dark:text-white">Content (Markdown supported)</label>
                <textarea
                  value={newArticle.content}
                  onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 min-h-[300px] dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  placeholder="Write your article content in Markdown..."
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 dark:text-white">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={newArticle.tags}
                  onChange={(e) => setNewArticle({ ...newArticle, tags: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  placeholder="e.g. tech, react, tutorial"
                />
              </div>
              <div className="flex gap-2">
                <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Publish
                </button>
                <button type="button" onClick={() => setShowWrite(false)} className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        ) : selected ? (
          <div>
            <button onClick={() => setSelected(null)} className="mb-4 text-blue-600 hover:underline">← Back</button>
            <h1 className="text-3xl font-bold mb-4 dark:text-white">{selected.title}</h1>
            <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
              <span>{new Date(selected.createdAt).toLocaleDateString()}</span>
              <span className="flex items-center gap-1"><Heart className="w-4 h-4" /> {selected.stats.likes}</span>
            </div>
            <div className="prose dark:prose-invert max-w-none bg-white dark:bg-gray-800 p-6 rounded-lg" dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(marked(selected.content)) }} />
          </div>
        ) : (
          <div className="space-y-6">
            {articles.map((article) => (
              <div key={article._id} onClick={() => setSelected(article)} className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <h2 className="text-xl font-bold mb-2 dark:text-white">{article.title}</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">{article.excerpt || article.content.slice(0, 150) + '...'}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">{new Date(article.createdAt).toLocaleDateString()}</span>
                  <span className="text-sm bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded dark:text-gray-300">{article.tags?.join(', ') || 'General'}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;

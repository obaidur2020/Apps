import { Request, Response, NextFunction } from 'express';

export interface AuthRequest extends Request {
  user?: { userId: string };
}

// Demo user ID - valid 24-character hex string (MongoDB ObjectId format)
const DEMO_USER_ID = '000000000000000000000001';

export const auth = (req: AuthRequest, res: Response, next: NextFunction) => {
  req.user = { userId: DEMO_USER_ID };
  next();
};

import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import articleRoutes from './routes/articles';
import userRoutes from './routes/users';

dotenv.config();
const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/blog-platform';
const port = process.env.PORT || 5005;
const clientOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';

mongoose.connect(mongoUri);

const app = express();
app.use(cors({ origin: clientOrigin }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'OK' }));
app.use('/api/articles', articleRoutes);
app.use('/api/users', userRoutes);

app.listen(port, () => console.log(`Blog Server on ${port}`));

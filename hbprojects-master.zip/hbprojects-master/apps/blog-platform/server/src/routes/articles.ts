import express from 'express';
import Article from '../models/Article';
import { auth } from '../middleware/auth';

const router = express.Router();

router.get('/', async (req, res) => {
  // Show all articles (including drafts) for demo purposes
  const articles = await Article.find().sort({ createdAt: -1 }).populate('authorId', 'name');
  res.json({ success: true, data: { articles } });
});

router.post('/', auth, async (req, res) => {
  // Default to published status if not provided
  const articleData = { ...req.body, status: req.body.status || 'published' };
  const article = await Article.create(articleData);
  res.status(201).json({ success: true, data: { article } });
});

router.get('/:slug', async (req, res) => {
  const article = await Article.findOne({ slug: req.params.slug }).populate('authorId', 'name');
  if (!article) return res.status(404).json({ success: false, error: { message: 'Not found' } });
  if (!article.stats) article.stats = { views: 0, likes: 0, comments: 0 };
  article.stats.views++;
  await article.save();
  res.json({ success: true, data: { article } });
});

router.post('/:id/like', async (req, res) => {
  const article = await Article.findById(req.params.id);
  if (!article) return res.status(404).json({ success: false, error: { message: 'Not found' } });
  if (!article.stats) article.stats = { views: 0, likes: 0, comments: 0 };
  article.stats.likes++;
  await article.save();
  res.json({ success: true, data: { likes: article.stats.likes } });
});

router.post('/:id/comments', async (req, res) => {
  const { content, userId } = req.body;
  const article = await Article.findById(req.params.id);
  if (!article) return res.status(404).json({ success: false, error: { message: 'Not found' } });
  if (!article.stats) article.stats = { views: 0, likes: 0, comments: 0 };
  article.stats.comments++;
  await article.save();
  res.json({ success: true, data: { message: 'Comment added' } });
});

export default router;

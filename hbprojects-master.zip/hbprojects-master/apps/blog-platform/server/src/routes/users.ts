import express from 'express';
import User from '../models/User';

const router = express.Router();

router.post('/register', async (req, res) => {
  const user = await User.create(req.body);
  res.status(201).json({ success: true, data: { user } });
});

router.get('/:id', async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  res.json({ success: true, data: { user } });
});

export default router;

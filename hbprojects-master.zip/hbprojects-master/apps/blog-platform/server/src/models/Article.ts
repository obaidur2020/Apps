import mongoose from 'mongoose';

const ArticleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  slug: { type: String, unique: true },
  content: { type: String, required: true },
  excerpt: String,
  coverImage: String,
  authorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  status: { type: String, enum: ['draft', 'published'], default: 'draft' },
  tags: [String],
  stats: { views: { type: Number, default: 0 }, likes: { type: Number, default: 0 }, comments: { type: Number, default: 0 } },
}, { timestamps: true });

ArticleSchema.index({ slug: 1 });
ArticleSchema.index({ status: 1, createdAt: -1 });

export default mongoose.model('Article', ArticleSchema);

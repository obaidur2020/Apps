import { useState } from 'react';
import { Cloud, Search, Thermometer, Wind, Droplets, Sun, CloudRain, CloudDrizzle, CloudLightning, MapPin } from 'lucide-react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';

const API_URL = 'http://localhost:5004/api';

interface WeatherData {
  name: string;
  sys: { country: string };
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
    temp_min: number;
    temp_max: number;
    pressure: number;
  };
  weather: Array<{ description: string; main: string }>;
  wind: { speed: number };
  visibility: number;
}

interface ApiError {
  response?: {
    data?: {
      error?: { message: string };
    };
  };
}

const getWeatherIcon = (condition: string) => {
  const cond = condition.toLowerCase();
  if (cond.includes('rain') || cond.includes('drizzle')) return CloudRain;
  if (cond.includes('thunder') || cond.includes('lightning')) return CloudLightning;
  if (cond.includes('cloud')) return Cloud;
  if (cond.includes('clear') || cond.includes('sun')) return Sun;
  return Cloud;
};

function App() {
  const [city, setCity] = useState('London');
  const [search, setSearch] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchWeather = async () => {
    if (!search.trim()) return;
    setLoading(true);
    try {
      const res = await axios.get<{ data: WeatherData }>(`${API_URL}/weather/current/${search}`);
      setWeather(res.data.data);
      setCity(search);
      setSearch('');
    } catch (error) {
      const err = error as ApiError;
      toast.error(err.response?.data?.error?.message || 'City not found');
    } finally {
      setLoading(false);
    }
  };

  const WeatherIcon = weather?.weather[0]?.main ? getWeatherIcon(weather.weather[0].main) : Cloud;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl"></div>
      </div>

      <Toaster position="top-center" />

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-lg">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center gap-3 mb-4">
              <div className="p-3 bg-white/20 backdrop-blur rounded-2xl">
                <Cloud className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white tracking-tight">Weather</h1>
            </div>
            <p className="text-blue-100 text-sm">Get real-time weather updates</p>
          </div>

          {/* Search */}
          <div className="flex gap-2 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && fetchWeather()}
                placeholder="Search for a city..."
                className="w-full pl-12 pr-4 py-4 bg-white/10 backdrop-blur border border-white/20 rounded-2xl text-white placeholder-blue-200 focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent transition-all"
              />
            </div>
            <button
              onClick={fetchWeather}
              disabled={loading}
              className="px-6 bg-white text-blue-600 rounded-2xl font-semibold hover:bg-blue-50 disabled:opacity-50 transition-all hover:scale-105 active:scale-95 shadow-lg"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
            </button>
          </div>

          {/* Weather Card */}
          {weather && (
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
              {/* Location & Main Temp */}
              <div className="p-8 text-center border-b border-white/10">
                <div className="flex items-center justify-center gap-2 text-blue-100 mb-2">
                  <MapPin className="w-4 h-4" />
                  <span className="font-medium">{weather.name}, {weather.sys.country}</span>
                </div>
                <div className="flex items-center justify-center gap-4 my-6">
                  <div className="p-4 bg-white/10 rounded-2xl">
                    <WeatherIcon className="w-16 h-16 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="text-7xl font-light text-white tracking-tighter">
                      {Math.round(weather.main.temp)}°
                    </div>
                    <div className="text-lg text-blue-100 capitalize mt-1">
                      {weather.weather[0].description}
                    </div>
                  </div>
                </div>
              </div>

              {/* Weather Details Grid */}
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4">
                  {/* Feels Like */}
                  <div className="bg-white/5 rounded-2xl p-4 hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-2 text-blue-200 mb-2">
                      <Thermometer className="w-4 h-4" />
                      <span className="text-sm font-medium">Feels Like</span>
                    </div>
                    <div className="text-2xl font-semibold text-white">
                      {Math.round(weather.main.feels_like)}°
                    </div>
                  </div>

                  {/* Humidity */}
                  <div className="bg-white/5 rounded-2xl p-4 hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-2 text-blue-200 mb-2">
                      <Droplets className="w-4 h-4" />
                      <span className="text-sm font-medium">Humidity</span>
                    </div>
                    <div className="text-2xl font-semibold text-white">
                      {weather.main.humidity}%
                    </div>
                  </div>

                  {/* Wind */}
                  <div className="bg-white/5 rounded-2xl p-4 hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-2 text-blue-200 mb-2">
                      <Wind className="w-4 h-4" />
                      <span className="text-sm font-medium">Wind</span>
                    </div>
                    <div className="text-2xl font-semibold text-white">
                      {Math.round(weather.wind.speed * 3.6)} <span className="text-base font-normal text-blue-200">km/h</span>
                    </div>
                  </div>

                  {/* Min/Max */}
                  <div className="bg-white/5 rounded-2xl p-4 hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-2 text-blue-200 mb-2">
                      <Thermometer className="w-4 h-4" />
                      <span className="text-sm font-medium">Min / Max</span>
                    </div>
                    <div className="text-2xl font-semibold text-white">
                      {Math.round(weather.main.temp_min)}° / {Math.round(weather.main.temp_max)}°
                    </div>
                  </div>
                </div>

                {/* Additional Info */}
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="bg-white/5 rounded-2xl p-4 text-center">
                    <div className="text-sm text-blue-200 mb-1">Pressure</div>
                    <div className="text-lg font-semibold text-white">{weather.main.pressure} hPa</div>
                  </div>
                  <div className="bg-white/5 rounded-2xl p-4 text-center">
                    <div className="text-sm text-blue-200 mb-1">Visibility</div>
                    <div className="text-lg font-semibold text-white">{(weather.visibility / 1000).toFixed(1)} km</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Empty State */}
          {!weather && !loading && (
            <div className="text-center py-16 animate-in fade-in duration-500">
              <div className="relative inline-block mb-6">
                <div className="absolute inset-0 bg-white/20 rounded-3xl blur-2xl"></div>
                <div className="relative p-6 bg-white/10 backdrop-blur rounded-3xl">
                  <Cloud className="w-20 h-20 text-white" />
                </div>
              </div>
              <h2 className="text-2xl font-semibold text-white mb-2">Enter a city name</h2>
              <p className="text-blue-100">Search for any city worldwide to see the weather</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;

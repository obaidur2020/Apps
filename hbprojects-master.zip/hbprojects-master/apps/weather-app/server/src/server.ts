import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import axios from 'axios';

dotenv.config();

interface ApiError {
  response?: {
    data?: { message: string };
  };
  message: string;
}

const app = express();
const PORT = process.env.PORT || 5004;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5180';
const API_KEY = process.env.OPENWEATHER_API_KEY;

app.use(cors({ origin: CLIENT_ORIGIN }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'OK' }));

app.get('/api/weather/current/:city', async (req, res) => {
  try {
    const { city } = req.params;
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`);
    res.json({ success: true, data: response.data });
  } catch (error) {
    const err = error as ApiError;
    res.status(500).json({ success: false, error: { message: err.response?.data?.message || 'Weather fetch failed' } });
  }
});

app.get('/api/weather/forecast/:city', async (req, res) => {
  try {
    const { city } = req.params;
    const geo = await axios.get(`https://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=${API_KEY}`);
    if (!geo.data[0]) throw new Error('City not found');

    const { lat, lon } = geo.data[0];
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`);
    res.json({ success: true, data: response.data });
  } catch (error) {
    const err = error as Error;
    res.status(500).json({ success: false, error: { message: err.message || 'Forecast fetch failed' } });
  }
});

app.listen(PORT, () => console.log(`Weather Server on port ${PORT}`));

# Weather App

A full-stack weather application with city search and modern UI design.

## 🚀 Quick Start

```bash
docker-compose up -d
```

## 🌐 Access

- **Frontend**: http://localhost:5180
- **Backend API**: http://localhost:5004
- **Health Check**: http://localhost:5004/health

## ✨ Features

- Search weather by city
- Current temperature and conditions
- Feels like temperature
- Humidity, wind speed, pressure
- Temperature min/max
- Visibility information
- Dynamic weather icons
- Modern gradient glassmorphism UI
- Responsive design

## 🔧 Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript, MongoDB
- **Database**: MongoDB
- **Weather API**: OpenWeatherMap (optional)

## 📁 Structure

```
weather-app/
├── client/          # React frontend
│   └── src/
│       ├── components/
│       └── services/
└── server/          # Express backend
    └── src/
        ├── models/
        ├── routes/
        └── controllers/
```

## 🐳 Docker Services

- `weather-app-server` - Backend API (port 5004)
- `weather-app-client` - Frontend UI (port 5180)

## 📝 API Endpoints

- `GET /api/weather/current/:city` - Get current weather for city
- `GET /api/health` - Health check

## 🔑 Environment Variables (Optional)

Add to `server/.env` for live weather data:

```env
OPENWEATHER_API_KEY=your_key_here
MONGODB_URI=mongodb://mongodb:27017/weather-app
PORT=5004
CLIENT_ORIGIN=http://localhost:5180
```

Get free API key at: https://openweathermap.org/api

**Note**: The app works in demo mode without an API key.
